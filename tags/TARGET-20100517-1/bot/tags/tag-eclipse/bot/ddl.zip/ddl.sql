-- phpMyAdmin SQL Dump
-- version 2.11.9.3
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Aug 16, 2009 at 06:12 PM
-- Server version: 5.0.81
-- PHP Version: 5.2.9

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";

--
-- Database: `y1910061_traviandb`
--

-- --------------------------------------------------------

--
-- Table structure for table `accounts`
--

CREATE TABLE IF NOT EXISTS `accounts` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `server` varbinary(255) NOT NULL default '',
  `user` varbinary(255) NOT NULL default '',
  `password` varbinary(255) NOT NULL default '',
  `race` varbinary(255) NOT NULL default '',
  `main_village` int(10) unsigned NOT NULL default '0',
  `busy` int(10) unsigned NOT NULL default '0',
  `last_report` int(10) unsigned NOT NULL default '0',
  `beacon` int(10) unsigned NOT NULL default '0',
  `message` tinyint(3) unsigned NOT NULL default '0',
  `redundant_resource` int(11) unsigned NOT NULL default '0' COMMENT '0 nothing, 1 wood, 2 clay, 3 iron, 4 wood+clay, 5 wood+iron, 6 clay+iron',
  `farm_lo` int(11) NOT NULL default '4',
  `farm_hi` int(11) NOT NULL default '10',
  `proxy` varchar(255) collate latin1_general_ci NOT NULL default '0',
  `next_check_time` timestamp NOT NULL default CURRENT_TIMESTAMP,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=23 ;

-- --------------------------------------------------------

--
-- Table structure for table `ally_reports`
--

CREATE TABLE IF NOT EXISTS `ally_reports` (
  `id` int(10) unsigned NOT NULL,
  `attack_uid` int(10) unsigned NOT NULL,
  `attacker` varbinary(255) NOT NULL,
  `attack_village` varbinary(255) NOT NULL,
  `attack_village_id` int(10) unsigned NOT NULL,
  `attack_ally` varbinary(255) default NULL,
  `attack_power` int(10) unsigned NOT NULL,
  `defend_uid` int(10) unsigned NOT NULL,
  `defender` varbinary(255) NOT NULL,
  `defend_village` varbinary(255) NOT NULL,
  `defend_village_id` int(10) unsigned NOT NULL,
  `defend_ally` varbinary(255) default NULL,
  `defend_power` int(10) unsigned default NULL,
  `datetime` varchar(255) NOT NULL,
  `content` blob NOT NULL,
  `title` varbinary(255) NOT NULL,
  `attack_village_id_c` varchar(255) NOT NULL,
  `defend_village_id_c` varchar(255) NOT NULL,
  `timestamp` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  PRIMARY KEY  (`id`),
  KEY `attack_uid` (`attack_uid`),
  KEY `defend_uid` (`defend_uid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `build`
--

CREATE TABLE IF NOT EXISTS `build` (
  `account` int(10) unsigned NOT NULL default '0',
  `seq` int(11) NOT NULL auto_increment,
  `id` int(11) NOT NULL default '0',
  `desc` varchar(255) default NULL,
  `village` int(11) NOT NULL default '0',
  `gid` tinyint(4) NOT NULL default '0',
  PRIMARY KEY  (`seq`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=15811 ;

-- --------------------------------------------------------

--
-- Table structure for table `build_names`
--

CREATE TABLE IF NOT EXISTS `build_names` (
  `account` int(10) unsigned NOT NULL default '0',
  `village` int(11) NOT NULL default '0',
  `id` int(11) NOT NULL default '0',
  `name` varchar(255) NOT NULL default '',
  `timestamp` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  PRIMARY KEY  (`village`,`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `gids`
--

CREATE TABLE IF NOT EXISTS `gids` (
  `gid` tinyint(3) unsigned NOT NULL default '0',
  `name` varbinary(255) NOT NULL default '',
  PRIMARY KEY  (`gid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `idle_villages_s1_travian_hk`
--

CREATE TABLE IF NOT EXISTS `idle_villages_s1_travian_hk` (
  `id` int(9) unsigned NOT NULL default '0',
  `x` smallint(3) NOT NULL default '0',
  `y` smallint(3) NOT NULL default '0',
  `tid` tinyint(1) unsigned NOT NULL default '0',
  `vid` int(9) unsigned NOT NULL default '0',
  `village` varbinary(255) NOT NULL default '',
  `uid` int(9) NOT NULL default '0',
  `player` varbinary(255) NOT NULL default '',
  `aid` int(9) unsigned NOT NULL default '0',
  `alliance` varbinary(255) NOT NULL default '',
  `population` smallint(5) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `idle_villages_s1_travian_jp`
--

CREATE TABLE IF NOT EXISTS `idle_villages_s1_travian_jp` (
  `id` int(9) unsigned NOT NULL default '0',
  `x` smallint(3) NOT NULL default '0',
  `y` smallint(3) NOT NULL default '0',
  `tid` tinyint(1) unsigned NOT NULL default '0',
  `vid` int(9) unsigned NOT NULL default '0',
  `village` varbinary(255) NOT NULL default '',
  `uid` int(9) NOT NULL default '0',
  `player` varbinary(255) NOT NULL default '',
  `aid` int(9) unsigned NOT NULL default '0',
  `alliance` varbinary(255) NOT NULL default '',
  `population` smallint(5) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `idle_villages_s1_travian_tw`
--

CREATE TABLE IF NOT EXISTS `idle_villages_s1_travian_tw` (
  `id` int(9) unsigned NOT NULL default '0',
  `x` smallint(3) NOT NULL default '0',
  `y` smallint(3) NOT NULL default '0',
  `tid` tinyint(1) unsigned NOT NULL default '0',
  `vid` int(9) unsigned NOT NULL default '0',
  `village` varbinary(255) NOT NULL default '',
  `uid` int(9) NOT NULL default '0',
  `player` varbinary(255) NOT NULL default '',
  `aid` int(9) unsigned NOT NULL default '0',
  `alliance` varbinary(255) NOT NULL default '',
  `population` smallint(5) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `idle_villages_s2_travian_hk`
--

CREATE TABLE IF NOT EXISTS `idle_villages_s2_travian_hk` (
  `id` int(9) unsigned NOT NULL default '0',
  `x` smallint(3) NOT NULL default '0',
  `y` smallint(3) NOT NULL default '0',
  `tid` tinyint(1) unsigned NOT NULL default '0',
  `vid` int(9) unsigned NOT NULL default '0',
  `village` varbinary(255) NOT NULL default '',
  `uid` int(9) NOT NULL default '0',
  `player` varbinary(255) NOT NULL default '',
  `aid` int(9) unsigned NOT NULL default '0',
  `alliance` varbinary(255) NOT NULL default '',
  `population` smallint(5) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `idle_villages_s2_travian_jp`
--

CREATE TABLE IF NOT EXISTS `idle_villages_s2_travian_jp` (
  `id` int(9) unsigned NOT NULL default '0',
  `x` smallint(3) NOT NULL default '0',
  `y` smallint(3) NOT NULL default '0',
  `tid` tinyint(1) unsigned NOT NULL default '0',
  `vid` int(9) unsigned NOT NULL default '0',
  `village` varbinary(255) NOT NULL default '',
  `uid` int(9) NOT NULL default '0',
  `player` varbinary(255) NOT NULL default '',
  `aid` int(9) unsigned NOT NULL default '0',
  `alliance` varbinary(255) NOT NULL default '',
  `population` smallint(5) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `idle_villages_s2_travian_tw`
--

CREATE TABLE IF NOT EXISTS `idle_villages_s2_travian_tw` (
  `id` int(9) unsigned NOT NULL default '0',
  `x` smallint(3) NOT NULL default '0',
  `y` smallint(3) NOT NULL default '0',
  `tid` tinyint(1) unsigned NOT NULL default '0',
  `vid` int(9) unsigned NOT NULL default '0',
  `village` varbinary(255) NOT NULL default '',
  `uid` int(9) NOT NULL default '0',
  `player` varbinary(255) NOT NULL default '',
  `aid` int(9) unsigned NOT NULL default '0',
  `alliance` varbinary(255) NOT NULL default '',
  `population` smallint(5) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `idle_villages_s3_travian_hk`
--

CREATE TABLE IF NOT EXISTS `idle_villages_s3_travian_hk` (
  `id` int(9) unsigned NOT NULL default '0',
  `x` smallint(3) NOT NULL default '0',
  `y` smallint(3) NOT NULL default '0',
  `tid` tinyint(1) unsigned NOT NULL default '0',
  `vid` int(9) unsigned NOT NULL default '0',
  `village` varbinary(255) NOT NULL default '',
  `uid` int(9) NOT NULL default '0',
  `player` varbinary(255) NOT NULL default '',
  `aid` int(9) unsigned NOT NULL default '0',
  `alliance` varbinary(255) NOT NULL default '',
  `population` smallint(5) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `idle_villages_s3_travian_jp`
--

CREATE TABLE IF NOT EXISTS `idle_villages_s3_travian_jp` (
  `id` int(9) unsigned NOT NULL default '0',
  `x` smallint(3) NOT NULL default '0',
  `y` smallint(3) NOT NULL default '0',
  `tid` tinyint(1) unsigned NOT NULL default '0',
  `vid` int(9) unsigned NOT NULL default '0',
  `village` varbinary(255) NOT NULL default '',
  `uid` int(9) NOT NULL default '0',
  `player` varbinary(255) NOT NULL default '',
  `aid` int(9) unsigned NOT NULL default '0',
  `alliance` varbinary(255) NOT NULL default '',
  `population` smallint(5) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `idle_villages_s3_travian_tw`
--

CREATE TABLE IF NOT EXISTS `idle_villages_s3_travian_tw` (
  `id` int(9) unsigned NOT NULL default '0',
  `x` smallint(3) NOT NULL default '0',
  `y` smallint(3) NOT NULL default '0',
  `tid` tinyint(1) unsigned NOT NULL default '0',
  `vid` int(9) unsigned NOT NULL default '0',
  `village` varbinary(255) NOT NULL default '',
  `uid` int(9) NOT NULL default '0',
  `player` varbinary(255) NOT NULL default '',
  `aid` int(9) unsigned NOT NULL default '0',
  `alliance` varbinary(255) NOT NULL default '',
  `population` smallint(5) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `idle_villages_s4_travian_com`
--

CREATE TABLE IF NOT EXISTS `idle_villages_s4_travian_com` (
  `id` int(9) unsigned NOT NULL default '0',
  `x` smallint(3) NOT NULL default '0',
  `y` smallint(3) NOT NULL default '0',
  `tid` tinyint(1) unsigned NOT NULL default '0',
  `vid` int(9) unsigned NOT NULL default '0',
  `village` varbinary(255) NOT NULL default '',
  `uid` int(9) NOT NULL default '0',
  `player` varbinary(255) NOT NULL default '',
  `aid` int(9) unsigned NOT NULL default '0',
  `alliance` varbinary(255) NOT NULL default '',
  `population` smallint(5) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `idle_villages_s4_travian_hk`
--

CREATE TABLE IF NOT EXISTS `idle_villages_s4_travian_hk` (
  `id` int(9) unsigned NOT NULL default '0',
  `x` smallint(3) NOT NULL default '0',
  `y` smallint(3) NOT NULL default '0',
  `tid` tinyint(1) unsigned NOT NULL default '0',
  `vid` int(9) unsigned NOT NULL default '0',
  `village` varbinary(255) NOT NULL default '',
  `uid` int(9) NOT NULL default '0',
  `player` varbinary(255) NOT NULL default '',
  `aid` int(9) unsigned NOT NULL default '0',
  `alliance` varbinary(255) NOT NULL default '',
  `population` smallint(5) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `idle_villages_s4_travian_jp`
--

CREATE TABLE IF NOT EXISTS `idle_villages_s4_travian_jp` (
  `id` int(9) unsigned NOT NULL default '0',
  `x` smallint(3) NOT NULL default '0',
  `y` smallint(3) NOT NULL default '0',
  `tid` tinyint(1) unsigned NOT NULL default '0',
  `vid` int(9) unsigned NOT NULL default '0',
  `village` varbinary(255) NOT NULL default '',
  `uid` int(9) NOT NULL default '0',
  `player` varbinary(255) NOT NULL default '',
  `aid` int(9) unsigned NOT NULL default '0',
  `alliance` varbinary(255) NOT NULL default '',
  `population` smallint(5) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `idle_villages_s4_travian_tw`
--

CREATE TABLE IF NOT EXISTS `idle_villages_s4_travian_tw` (
  `id` int(9) unsigned NOT NULL default '0',
  `x` smallint(3) NOT NULL default '0',
  `y` smallint(3) NOT NULL default '0',
  `tid` tinyint(1) unsigned NOT NULL default '0',
  `vid` int(9) unsigned NOT NULL default '0',
  `village` varbinary(255) NOT NULL default '',
  `uid` int(9) NOT NULL default '0',
  `player` varbinary(255) NOT NULL default '',
  `aid` int(9) unsigned NOT NULL default '0',
  `alliance` varbinary(255) NOT NULL default '',
  `population` smallint(5) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `idle_villages_s5_travian_hk`
--

CREATE TABLE IF NOT EXISTS `idle_villages_s5_travian_hk` (
  `id` int(9) unsigned NOT NULL default '0',
  `x` smallint(3) NOT NULL default '0',
  `y` smallint(3) NOT NULL default '0',
  `tid` tinyint(1) unsigned NOT NULL default '0',
  `vid` int(9) unsigned NOT NULL default '0',
  `village` varbinary(255) NOT NULL default '',
  `uid` int(9) NOT NULL default '0',
  `player` varbinary(255) NOT NULL default '',
  `aid` int(9) unsigned NOT NULL default '0',
  `alliance` varbinary(255) NOT NULL default '',
  `population` smallint(5) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `idle_villages_s5_travian_jp`
--

CREATE TABLE IF NOT EXISTS `idle_villages_s5_travian_jp` (
  `id` int(9) unsigned NOT NULL default '0',
  `x` smallint(3) NOT NULL default '0',
  `y` smallint(3) NOT NULL default '0',
  `tid` tinyint(1) unsigned NOT NULL default '0',
  `vid` int(9) unsigned NOT NULL default '0',
  `village` varbinary(255) NOT NULL default '',
  `uid` int(9) NOT NULL default '0',
  `player` varbinary(255) NOT NULL default '',
  `aid` int(9) unsigned NOT NULL default '0',
  `alliance` varbinary(255) NOT NULL default '',
  `population` smallint(5) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `idle_villages_s5_travian_tw`
--

CREATE TABLE IF NOT EXISTS `idle_villages_s5_travian_tw` (
  `id` int(9) unsigned NOT NULL default '0',
  `x` smallint(3) NOT NULL default '0',
  `y` smallint(3) NOT NULL default '0',
  `tid` tinyint(1) unsigned NOT NULL default '0',
  `vid` int(9) unsigned NOT NULL default '0',
  `village` varbinary(255) NOT NULL default '',
  `uid` int(9) NOT NULL default '0',
  `player` varbinary(255) NOT NULL default '',
  `aid` int(9) unsigned NOT NULL default '0',
  `alliance` varbinary(255) NOT NULL default '',
  `population` smallint(5) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `idle_villages_s6_travian_hk`
--

CREATE TABLE IF NOT EXISTS `idle_villages_s6_travian_hk` (
  `id` int(9) unsigned NOT NULL default '0',
  `x` smallint(3) NOT NULL default '0',
  `y` smallint(3) NOT NULL default '0',
  `tid` tinyint(1) unsigned NOT NULL default '0',
  `vid` int(9) unsigned NOT NULL default '0',
  `village` varbinary(255) NOT NULL default '',
  `uid` int(9) NOT NULL default '0',
  `player` varbinary(255) NOT NULL default '',
  `aid` int(9) unsigned NOT NULL default '0',
  `alliance` varbinary(255) NOT NULL default '',
  `population` smallint(5) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `idle_villages_s6_travian_tw`
--

CREATE TABLE IF NOT EXISTS `idle_villages_s6_travian_tw` (
  `id` int(9) unsigned NOT NULL default '0',
  `x` smallint(3) NOT NULL default '0',
  `y` smallint(3) NOT NULL default '0',
  `tid` tinyint(1) unsigned NOT NULL default '0',
  `vid` int(9) unsigned NOT NULL default '0',
  `village` varbinary(255) NOT NULL default '',
  `uid` int(9) NOT NULL default '0',
  `player` varbinary(255) NOT NULL default '',
  `aid` int(9) unsigned NOT NULL default '0',
  `alliance` varbinary(255) NOT NULL default '',
  `population` smallint(5) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `idle_villages_speed2_travian_cn`
--

CREATE TABLE IF NOT EXISTS `idle_villages_speed2_travian_cn` (
  `id` int(9) unsigned NOT NULL default '0',
  `x` smallint(3) NOT NULL default '0',
  `y` smallint(3) NOT NULL default '0',
  `tid` tinyint(1) unsigned NOT NULL default '0',
  `vid` int(9) unsigned NOT NULL default '0',
  `village` varbinary(255) NOT NULL default '',
  `uid` int(9) NOT NULL default '0',
  `player` varbinary(255) NOT NULL default '',
  `aid` int(9) unsigned NOT NULL default '0',
  `alliance` varbinary(255) NOT NULL default '',
  `population` smallint(5) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `idle_villages_speed_travian_hk`
--

CREATE TABLE IF NOT EXISTS `idle_villages_speed_travian_hk` (
  `id` int(9) unsigned NOT NULL default '0',
  `x` smallint(3) NOT NULL default '0',
  `y` smallint(3) NOT NULL default '0',
  `tid` tinyint(1) unsigned NOT NULL default '0',
  `vid` int(9) unsigned NOT NULL default '0',
  `village` varbinary(255) NOT NULL default '',
  `uid` int(9) NOT NULL default '0',
  `player` varbinary(255) NOT NULL default '',
  `aid` int(9) unsigned NOT NULL default '0',
  `alliance` varbinary(255) NOT NULL default '',
  `population` smallint(5) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `idle_villages_speed_travian_jp`
--

CREATE TABLE IF NOT EXISTS `idle_villages_speed_travian_jp` (
  `id` int(9) unsigned NOT NULL default '0',
  `x` smallint(3) NOT NULL default '0',
  `y` smallint(3) NOT NULL default '0',
  `tid` tinyint(1) unsigned NOT NULL default '0',
  `vid` int(9) unsigned NOT NULL default '0',
  `village` varbinary(255) NOT NULL default '',
  `uid` int(9) NOT NULL default '0',
  `player` varbinary(255) NOT NULL default '',
  `aid` int(9) unsigned NOT NULL default '0',
  `alliance` varbinary(255) NOT NULL default '',
  `population` smallint(5) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `idle_villages_speed_travian_tw`
--

CREATE TABLE IF NOT EXISTS `idle_villages_speed_travian_tw` (
  `id` int(9) unsigned NOT NULL default '0',
  `x` smallint(3) NOT NULL default '0',
  `y` smallint(3) NOT NULL default '0',
  `tid` tinyint(1) unsigned NOT NULL default '0',
  `vid` int(9) unsigned NOT NULL default '0',
  `village` varbinary(255) NOT NULL default '',
  `uid` int(9) NOT NULL default '0',
  `player` varbinary(255) NOT NULL default '',
  `aid` int(9) unsigned NOT NULL default '0',
  `alliance` varbinary(255) NOT NULL default '',
  `population` smallint(5) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `idle_villages_speed_travian_us`
--

CREATE TABLE IF NOT EXISTS `idle_villages_speed_travian_us` (
  `id` int(9) unsigned NOT NULL default '0',
  `x` smallint(3) NOT NULL default '0',
  `y` smallint(3) NOT NULL default '0',
  `tid` tinyint(1) unsigned NOT NULL default '0',
  `vid` int(9) unsigned NOT NULL default '0',
  `village` varbinary(255) NOT NULL default '',
  `uid` int(9) NOT NULL default '0',
  `player` varbinary(255) NOT NULL default '',
  `aid` int(9) unsigned NOT NULL default '0',
  `alliance` varbinary(255) NOT NULL default '',
  `population` smallint(5) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `mission`
--

CREATE TABLE IF NOT EXISTS `mission` (
  `seq` int(10) unsigned NOT NULL auto_increment,
  `account` int(11) NOT NULL,
  `x` int(11) NOT NULL default '0',
  `y` int(11) NOT NULL default '0',
  `hour` int(10) unsigned NOT NULL default '0',
  `min_clubs` int(10) unsigned NOT NULL default '0',
  `recursive` int(10) unsigned NOT NULL default '0',
  `village` int(11) NOT NULL default '0',
  `ram` int(11) NOT NULL default '0',
  PRIMARY KEY  (`seq`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC AUTO_INCREMENT=308 ;

-- --------------------------------------------------------

--
-- Table structure for table `populations`
--

CREATE TABLE IF NOT EXISTS `populations` (
  `x` int(11) NOT NULL default '0',
  `y` int(11) NOT NULL default '0',
  `player_name` varchar(255) NOT NULL default '',
  `population` int(10) unsigned NOT NULL default '0',
  `village_name` varchar(255) NOT NULL default '',
  `ally_name` varchar(255) NOT NULL default '',
  `d` int(10) unsigned NOT NULL default '0',
  `c` varchar(45) NOT NULL default '',
  `distance` float NOT NULL default '0',
  `nearest_village` int(11) NOT NULL default '0',
  `daystamp` int(11) NOT NULL default '0',
  PRIMARY KEY  (`x`,`y`,`daystamp`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

-- --------------------------------------------------------

--
-- Table structure for table `reports`
--

CREATE TABLE IF NOT EXISTS `reports` (
  `account` int(11) NOT NULL,
  `id` int(10) NOT NULL default '0',
  `title` varbinary(255) NOT NULL default '',
  `read` int(11) NOT NULL default '0',
  PRIMARY KEY  (`account`,`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `servers`
--

CREATE TABLE IF NOT EXISTS `servers` (
  `addr` varbinary(255) NOT NULL default '',
  `wood_name` varbinary(255) NOT NULL default '',
  `brick_name` varbinary(255) NOT NULL default '',
  `iron_name` varbinary(255) NOT NULL default '',
  `crop_name` varbinary(255) NOT NULL default '',
  `empty_space` varbinary(255) NOT NULL default '',
  `report_str` varbinary(255) NOT NULL,
  PRIMARY KEY  (`addr`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `targets`
--

CREATE TABLE IF NOT EXISTS `targets` (
  `account` int(11) NOT NULL,
  `x` int(11) NOT NULL default '0',
  `y` int(11) NOT NULL default '0',
  `timestamp` timestamp NOT NULL default CURRENT_TIMESTAMP,
  `invalid` int(11) NOT NULL default '0',
  `raid` int(11) NOT NULL default '0',
  `invalid_msg` varchar(255) character set utf8 collate utf8_bin default NULL,
  `timespan` int(11) NOT NULL default '0',
  `village` int(11) NOT NULL default '0',
  `interval` int(11) NOT NULL default '1',
  `score` varchar(255) NOT NULL,
  `player` varbinary(255) default NULL,
  `avg_score` int(11) NOT NULL default '60',
  PRIMARY KEY  (`account`,`x`,`y`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `villages`
--

CREATE TABLE IF NOT EXISTS `villages` (
  `account` int(10) unsigned NOT NULL default '0',
  `id` int(10) unsigned NOT NULL default '0',
  `name` varbinary(255) NOT NULL default '',
  `x` int(11) NOT NULL default '0',
  `y` int(11) NOT NULL default '0',
  `auto_transfer` int(11) NOT NULL default '0',
  `noraid` int(11) NOT NULL default '0',
  `newbie` int(10) unsigned NOT NULL default '0',
  `last_beg` int(10) unsigned NOT NULL default '0',
  `crop` int(11) NOT NULL default '0',
  `cart_capacity` int(10) unsigned NOT NULL default '0',
  `defence` int(10) unsigned NOT NULL default '0',
  `party` int(10) unsigned NOT NULL default '0',
  `party_due_time` int(11) NOT NULL default '0',
  PRIMARY KEY  (`account`,`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `x_world_s1_travian_hk_090812`
--

CREATE TABLE IF NOT EXISTS `x_world_s1_travian_hk_090812` (
  `id` int(9) unsigned NOT NULL default '0',
  `x` smallint(3) NOT NULL default '0',
  `y` smallint(3) NOT NULL default '0',
  `tid` tinyint(1) unsigned NOT NULL default '0',
  `vid` int(9) unsigned NOT NULL default '0',
  `village` varbinary(255) NOT NULL default '',
  `uid` int(9) NOT NULL default '0',
  `player` varbinary(255) NOT NULL default '',
  `aid` int(9) unsigned NOT NULL default '0',
  `alliance` varbinary(255) NOT NULL default '',
  `population` smallint(5) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `x_world_s1_travian_hk_090813`
--

CREATE TABLE IF NOT EXISTS `x_world_s1_travian_hk_090813` (
  `id` int(9) unsigned NOT NULL default '0',
  `x` smallint(3) NOT NULL default '0',
  `y` smallint(3) NOT NULL default '0',
  `tid` tinyint(1) unsigned NOT NULL default '0',
  `vid` int(9) unsigned NOT NULL default '0',
  `village` varbinary(255) NOT NULL default '',
  `uid` int(9) NOT NULL default '0',
  `player` varbinary(255) NOT NULL default '',
  `aid` int(9) unsigned NOT NULL default '0',
  `alliance` varbinary(255) NOT NULL default '',
  `population` smallint(5) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `x_world_s1_travian_hk_090814`
--

CREATE TABLE IF NOT EXISTS `x_world_s1_travian_hk_090814` (
  `id` int(9) unsigned NOT NULL default '0',
  `x` smallint(3) NOT NULL default '0',
  `y` smallint(3) NOT NULL default '0',
  `tid` tinyint(1) unsigned NOT NULL default '0',
  `vid` int(9) unsigned NOT NULL default '0',
  `village` varbinary(255) NOT NULL default '',
  `uid` int(9) NOT NULL default '0',
  `player` varbinary(255) NOT NULL default '',
  `aid` int(9) unsigned NOT NULL default '0',
  `alliance` varbinary(255) NOT NULL default '',
  `population` smallint(5) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `x_world_s1_travian_hk_090815`
--

CREATE TABLE IF NOT EXISTS `x_world_s1_travian_hk_090815` (
  `id` int(9) unsigned NOT NULL default '0',
  `x` smallint(3) NOT NULL default '0',
  `y` smallint(3) NOT NULL default '0',
  `tid` tinyint(1) unsigned NOT NULL default '0',
  `vid` int(9) unsigned NOT NULL default '0',
  `village` varbinary(255) NOT NULL default '',
  `uid` int(9) NOT NULL default '0',
  `player` varbinary(255) NOT NULL default '',
  `aid` int(9) unsigned NOT NULL default '0',
  `alliance` varbinary(255) NOT NULL default '',
  `population` smallint(5) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `x_world_s1_travian_hk_090816`
--

CREATE TABLE IF NOT EXISTS `x_world_s1_travian_hk_090816` (
  `id` int(9) unsigned NOT NULL default '0',
  `x` smallint(3) NOT NULL default '0',
  `y` smallint(3) NOT NULL default '0',
  `tid` tinyint(1) unsigned NOT NULL default '0',
  `vid` int(9) unsigned NOT NULL default '0',
  `village` varbinary(255) NOT NULL default '',
  `uid` int(9) NOT NULL default '0',
  `player` varbinary(255) NOT NULL default '',
  `aid` int(9) unsigned NOT NULL default '0',
  `alliance` varbinary(255) NOT NULL default '',
  `population` smallint(5) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `x_world_s1_travian_jp_090812`
--

CREATE TABLE IF NOT EXISTS `x_world_s1_travian_jp_090812` (
  `id` int(9) unsigned NOT NULL default '0',
  `x` smallint(3) NOT NULL default '0',
  `y` smallint(3) NOT NULL default '0',
  `tid` tinyint(1) unsigned NOT NULL default '0',
  `vid` int(9) unsigned NOT NULL default '0',
  `village` varbinary(255) NOT NULL default '',
  `uid` int(9) NOT NULL default '0',
  `player` varbinary(255) NOT NULL default '',
  `aid` int(9) unsigned NOT NULL default '0',
  `alliance` varbinary(255) NOT NULL default '',
  `population` smallint(5) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `x_world_s1_travian_jp_090813`
--

CREATE TABLE IF NOT EXISTS `x_world_s1_travian_jp_090813` (
  `id` int(9) unsigned NOT NULL default '0',
  `x` smallint(3) NOT NULL default '0',
  `y` smallint(3) NOT NULL default '0',
  `tid` tinyint(1) unsigned NOT NULL default '0',
  `vid` int(9) unsigned NOT NULL default '0',
  `village` varbinary(255) NOT NULL default '',
  `uid` int(9) NOT NULL default '0',
  `player` varbinary(255) NOT NULL default '',
  `aid` int(9) unsigned NOT NULL default '0',
  `alliance` varbinary(255) NOT NULL default '',
  `population` smallint(5) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `x_world_s1_travian_jp_090814`
--

CREATE TABLE IF NOT EXISTS `x_world_s1_travian_jp_090814` (
  `id` int(9) unsigned NOT NULL default '0',
  `x` smallint(3) NOT NULL default '0',
  `y` smallint(3) NOT NULL default '0',
  `tid` tinyint(1) unsigned NOT NULL default '0',
  `vid` int(9) unsigned NOT NULL default '0',
  `village` varbinary(255) NOT NULL default '',
  `uid` int(9) NOT NULL default '0',
  `player` varbinary(255) NOT NULL default '',
  `aid` int(9) unsigned NOT NULL default '0',
  `alliance` varbinary(255) NOT NULL default '',
  `population` smallint(5) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `x_world_s1_travian_jp_090815`
--

CREATE TABLE IF NOT EXISTS `x_world_s1_travian_jp_090815` (
  `id` int(9) unsigned NOT NULL default '0',
  `x` smallint(3) NOT NULL default '0',
  `y` smallint(3) NOT NULL default '0',
  `tid` tinyint(1) unsigned NOT NULL default '0',
  `vid` int(9) unsigned NOT NULL default '0',
  `village` varbinary(255) NOT NULL default '',
  `uid` int(9) NOT NULL default '0',
  `player` varbinary(255) NOT NULL default '',
  `aid` int(9) unsigned NOT NULL default '0',
  `alliance` varbinary(255) NOT NULL default '',
  `population` smallint(5) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `x_world_s1_travian_jp_090816`
--

CREATE TABLE IF NOT EXISTS `x_world_s1_travian_jp_090816` (
  `id` int(9) unsigned NOT NULL default '0',
  `x` smallint(3) NOT NULL default '0',
  `y` smallint(3) NOT NULL default '0',
  `tid` tinyint(1) unsigned NOT NULL default '0',
  `vid` int(9) unsigned NOT NULL default '0',
  `village` varbinary(255) NOT NULL default '',
  `uid` int(9) NOT NULL default '0',
  `player` varbinary(255) NOT NULL default '',
  `aid` int(9) unsigned NOT NULL default '0',
  `alliance` varbinary(255) NOT NULL default '',
  `population` smallint(5) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `x_world_s1_travian_tw_090812`
--

CREATE TABLE IF NOT EXISTS `x_world_s1_travian_tw_090812` (
  `id` int(9) unsigned NOT NULL default '0',
  `x` smallint(3) NOT NULL default '0',
  `y` smallint(3) NOT NULL default '0',
  `tid` tinyint(1) unsigned NOT NULL default '0',
  `vid` int(9) unsigned NOT NULL default '0',
  `village` varbinary(255) NOT NULL default '',
  `uid` int(9) NOT NULL default '0',
  `player` varbinary(255) NOT NULL default '',
  `aid` int(9) unsigned NOT NULL default '0',
  `alliance` varbinary(255) NOT NULL default '',
  `population` smallint(5) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `x_world_s1_travian_tw_090813`
--

CREATE TABLE IF NOT EXISTS `x_world_s1_travian_tw_090813` (
  `id` int(9) unsigned NOT NULL default '0',
  `x` smallint(3) NOT NULL default '0',
  `y` smallint(3) NOT NULL default '0',
  `tid` tinyint(1) unsigned NOT NULL default '0',
  `vid` int(9) unsigned NOT NULL default '0',
  `village` varbinary(255) NOT NULL default '',
  `uid` int(9) NOT NULL default '0',
  `player` varbinary(255) NOT NULL default '',
  `aid` int(9) unsigned NOT NULL default '0',
  `alliance` varbinary(255) NOT NULL default '',
  `population` smallint(5) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `x_world_s1_travian_tw_090814`
--

CREATE TABLE IF NOT EXISTS `x_world_s1_travian_tw_090814` (
  `id` int(9) unsigned NOT NULL default '0',
  `x` smallint(3) NOT NULL default '0',
  `y` smallint(3) NOT NULL default '0',
  `tid` tinyint(1) unsigned NOT NULL default '0',
  `vid` int(9) unsigned NOT NULL default '0',
  `village` varbinary(255) NOT NULL default '',
  `uid` int(9) NOT NULL default '0',
  `player` varbinary(255) NOT NULL default '',
  `aid` int(9) unsigned NOT NULL default '0',
  `alliance` varbinary(255) NOT NULL default '',
  `population` smallint(5) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `x_world_s1_travian_tw_090815`
--

CREATE TABLE IF NOT EXISTS `x_world_s1_travian_tw_090815` (
  `id` int(9) unsigned NOT NULL default '0',
  `x` smallint(3) NOT NULL default '0',
  `y` smallint(3) NOT NULL default '0',
  `tid` tinyint(1) unsigned NOT NULL default '0',
  `vid` int(9) unsigned NOT NULL default '0',
  `village` varbinary(255) NOT NULL default '',
  `uid` int(9) NOT NULL default '0',
  `player` varbinary(255) NOT NULL default '',
  `aid` int(9) unsigned NOT NULL default '0',
  `alliance` varbinary(255) NOT NULL default '',
  `population` smallint(5) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `x_world_s1_travian_tw_090816`
--

CREATE TABLE IF NOT EXISTS `x_world_s1_travian_tw_090816` (
  `id` int(9) unsigned NOT NULL default '0',
  `x` smallint(3) NOT NULL default '0',
  `y` smallint(3) NOT NULL default '0',
  `tid` tinyint(1) unsigned NOT NULL default '0',
  `vid` int(9) unsigned NOT NULL default '0',
  `village` varbinary(255) NOT NULL default '',
  `uid` int(9) NOT NULL default '0',
  `player` varbinary(255) NOT NULL default '',
  `aid` int(9) unsigned NOT NULL default '0',
  `alliance` varbinary(255) NOT NULL default '',
  `population` smallint(5) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `x_world_s2_travian_hk_090812`
--

CREATE TABLE IF NOT EXISTS `x_world_s2_travian_hk_090812` (
  `id` int(9) unsigned NOT NULL default '0',
  `x` smallint(3) NOT NULL default '0',
  `y` smallint(3) NOT NULL default '0',
  `tid` tinyint(1) unsigned NOT NULL default '0',
  `vid` int(9) unsigned NOT NULL default '0',
  `village` varbinary(255) NOT NULL default '',
  `uid` int(9) NOT NULL default '0',
  `player` varbinary(255) NOT NULL default '',
  `aid` int(9) unsigned NOT NULL default '0',
  `alliance` varbinary(255) NOT NULL default '',
  `population` smallint(5) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `x_world_s2_travian_hk_090813`
--

CREATE TABLE IF NOT EXISTS `x_world_s2_travian_hk_090813` (
  `id` int(9) unsigned NOT NULL default '0',
  `x` smallint(3) NOT NULL default '0',
  `y` smallint(3) NOT NULL default '0',
  `tid` tinyint(1) unsigned NOT NULL default '0',
  `vid` int(9) unsigned NOT NULL default '0',
  `village` varbinary(255) NOT NULL default '',
  `uid` int(9) NOT NULL default '0',
  `player` varbinary(255) NOT NULL default '',
  `aid` int(9) unsigned NOT NULL default '0',
  `alliance` varbinary(255) NOT NULL default '',
  `population` smallint(5) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `x_world_s2_travian_hk_090814`
--

CREATE TABLE IF NOT EXISTS `x_world_s2_travian_hk_090814` (
  `id` int(9) unsigned NOT NULL default '0',
  `x` smallint(3) NOT NULL default '0',
  `y` smallint(3) NOT NULL default '0',
  `tid` tinyint(1) unsigned NOT NULL default '0',
  `vid` int(9) unsigned NOT NULL default '0',
  `village` varbinary(255) NOT NULL default '',
  `uid` int(9) NOT NULL default '0',
  `player` varbinary(255) NOT NULL default '',
  `aid` int(9) unsigned NOT NULL default '0',
  `alliance` varbinary(255) NOT NULL default '',
  `population` smallint(5) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `x_world_s2_travian_hk_090815`
--

CREATE TABLE IF NOT EXISTS `x_world_s2_travian_hk_090815` (
  `id` int(9) unsigned NOT NULL default '0',
  `x` smallint(3) NOT NULL default '0',
  `y` smallint(3) NOT NULL default '0',
  `tid` tinyint(1) unsigned NOT NULL default '0',
  `vid` int(9) unsigned NOT NULL default '0',
  `village` varbinary(255) NOT NULL default '',
  `uid` int(9) NOT NULL default '0',
  `player` varbinary(255) NOT NULL default '',
  `aid` int(9) unsigned NOT NULL default '0',
  `alliance` varbinary(255) NOT NULL default '',
  `population` smallint(5) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `x_world_s2_travian_hk_090816`
--

CREATE TABLE IF NOT EXISTS `x_world_s2_travian_hk_090816` (
  `id` int(9) unsigned NOT NULL default '0',
  `x` smallint(3) NOT NULL default '0',
  `y` smallint(3) NOT NULL default '0',
  `tid` tinyint(1) unsigned NOT NULL default '0',
  `vid` int(9) unsigned NOT NULL default '0',
  `village` varbinary(255) NOT NULL default '',
  `uid` int(9) NOT NULL default '0',
  `player` varbinary(255) NOT NULL default '',
  `aid` int(9) unsigned NOT NULL default '0',
  `alliance` varbinary(255) NOT NULL default '',
  `population` smallint(5) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `x_world_s2_travian_jp_090812`
--

CREATE TABLE IF NOT EXISTS `x_world_s2_travian_jp_090812` (
  `id` int(9) unsigned NOT NULL default '0',
  `x` smallint(3) NOT NULL default '0',
  `y` smallint(3) NOT NULL default '0',
  `tid` tinyint(1) unsigned NOT NULL default '0',
  `vid` int(9) unsigned NOT NULL default '0',
  `village` varbinary(255) NOT NULL default '',
  `uid` int(9) NOT NULL default '0',
  `player` varbinary(255) NOT NULL default '',
  `aid` int(9) unsigned NOT NULL default '0',
  `alliance` varbinary(255) NOT NULL default '',
  `population` smallint(5) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `x_world_s2_travian_jp_090813`
--

CREATE TABLE IF NOT EXISTS `x_world_s2_travian_jp_090813` (
  `id` int(9) unsigned NOT NULL default '0',
  `x` smallint(3) NOT NULL default '0',
  `y` smallint(3) NOT NULL default '0',
  `tid` tinyint(1) unsigned NOT NULL default '0',
  `vid` int(9) unsigned NOT NULL default '0',
  `village` varbinary(255) NOT NULL default '',
  `uid` int(9) NOT NULL default '0',
  `player` varbinary(255) NOT NULL default '',
  `aid` int(9) unsigned NOT NULL default '0',
  `alliance` varbinary(255) NOT NULL default '',
  `population` smallint(5) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `x_world_s2_travian_jp_090814`
--

CREATE TABLE IF NOT EXISTS `x_world_s2_travian_jp_090814` (
  `id` int(9) unsigned NOT NULL default '0',
  `x` smallint(3) NOT NULL default '0',
  `y` smallint(3) NOT NULL default '0',
  `tid` tinyint(1) unsigned NOT NULL default '0',
  `vid` int(9) unsigned NOT NULL default '0',
  `village` varbinary(255) NOT NULL default '',
  `uid` int(9) NOT NULL default '0',
  `player` varbinary(255) NOT NULL default '',
  `aid` int(9) unsigned NOT NULL default '0',
  `alliance` varbinary(255) NOT NULL default '',
  `population` smallint(5) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `x_world_s2_travian_jp_090815`
--

CREATE TABLE IF NOT EXISTS `x_world_s2_travian_jp_090815` (
  `id` int(9) unsigned NOT NULL default '0',
  `x` smallint(3) NOT NULL default '0',
  `y` smallint(3) NOT NULL default '0',
  `tid` tinyint(1) unsigned NOT NULL default '0',
  `vid` int(9) unsigned NOT NULL default '0',
  `village` varbinary(255) NOT NULL default '',
  `uid` int(9) NOT NULL default '0',
  `player` varbinary(255) NOT NULL default '',
  `aid` int(9) unsigned NOT NULL default '0',
  `alliance` varbinary(255) NOT NULL default '',
  `population` smallint(5) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `x_world_s2_travian_jp_090816`
--

CREATE TABLE IF NOT EXISTS `x_world_s2_travian_jp_090816` (
  `id` int(9) unsigned NOT NULL default '0',
  `x` smallint(3) NOT NULL default '0',
  `y` smallint(3) NOT NULL default '0',
  `tid` tinyint(1) unsigned NOT NULL default '0',
  `vid` int(9) unsigned NOT NULL default '0',
  `village` varbinary(255) NOT NULL default '',
  `uid` int(9) NOT NULL default '0',
  `player` varbinary(255) NOT NULL default '',
  `aid` int(9) unsigned NOT NULL default '0',
  `alliance` varbinary(255) NOT NULL default '',
  `population` smallint(5) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `x_world_s2_travian_tw_090812`
--

CREATE TABLE IF NOT EXISTS `x_world_s2_travian_tw_090812` (
  `id` int(9) unsigned NOT NULL default '0',
  `x` smallint(3) NOT NULL default '0',
  `y` smallint(3) NOT NULL default '0',
  `tid` tinyint(1) unsigned NOT NULL default '0',
  `vid` int(9) unsigned NOT NULL default '0',
  `village` varbinary(255) NOT NULL default '',
  `uid` int(9) NOT NULL default '0',
  `player` varbinary(255) NOT NULL default '',
  `aid` int(9) unsigned NOT NULL default '0',
  `alliance` varbinary(255) NOT NULL default '',
  `population` smallint(5) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `x_world_s2_travian_tw_090813`
--

CREATE TABLE IF NOT EXISTS `x_world_s2_travian_tw_090813` (
  `id` int(9) unsigned NOT NULL default '0',
  `x` smallint(3) NOT NULL default '0',
  `y` smallint(3) NOT NULL default '0',
  `tid` tinyint(1) unsigned NOT NULL default '0',
  `vid` int(9) unsigned NOT NULL default '0',
  `village` varbinary(255) NOT NULL default '',
  `uid` int(9) NOT NULL default '0',
  `player` varbinary(255) NOT NULL default '',
  `aid` int(9) unsigned NOT NULL default '0',
  `alliance` varbinary(255) NOT NULL default '',
  `population` smallint(5) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `x_world_s2_travian_tw_090814`
--

CREATE TABLE IF NOT EXISTS `x_world_s2_travian_tw_090814` (
  `id` int(9) unsigned NOT NULL default '0',
  `x` smallint(3) NOT NULL default '0',
  `y` smallint(3) NOT NULL default '0',
  `tid` tinyint(1) unsigned NOT NULL default '0',
  `vid` int(9) unsigned NOT NULL default '0',
  `village` varbinary(255) NOT NULL default '',
  `uid` int(9) NOT NULL default '0',
  `player` varbinary(255) NOT NULL default '',
  `aid` int(9) unsigned NOT NULL default '0',
  `alliance` varbinary(255) NOT NULL default '',
  `population` smallint(5) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `x_world_s2_travian_tw_090815`
--

CREATE TABLE IF NOT EXISTS `x_world_s2_travian_tw_090815` (
  `id` int(9) unsigned NOT NULL default '0',
  `x` smallint(3) NOT NULL default '0',
  `y` smallint(3) NOT NULL default '0',
  `tid` tinyint(1) unsigned NOT NULL default '0',
  `vid` int(9) unsigned NOT NULL default '0',
  `village` varbinary(255) NOT NULL default '',
  `uid` int(9) NOT NULL default '0',
  `player` varbinary(255) NOT NULL default '',
  `aid` int(9) unsigned NOT NULL default '0',
  `alliance` varbinary(255) NOT NULL default '',
  `population` smallint(5) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `x_world_s2_travian_tw_090816`
--

CREATE TABLE IF NOT EXISTS `x_world_s2_travian_tw_090816` (
  `id` int(9) unsigned NOT NULL default '0',
  `x` smallint(3) NOT NULL default '0',
  `y` smallint(3) NOT NULL default '0',
  `tid` tinyint(1) unsigned NOT NULL default '0',
  `vid` int(9) unsigned NOT NULL default '0',
  `village` varbinary(255) NOT NULL default '',
  `uid` int(9) NOT NULL default '0',
  `player` varbinary(255) NOT NULL default '',
  `aid` int(9) unsigned NOT NULL default '0',
  `alliance` varbinary(255) NOT NULL default '',
  `population` smallint(5) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `x_world_s3_travian_hk_090812`
--

CREATE TABLE IF NOT EXISTS `x_world_s3_travian_hk_090812` (
  `id` int(9) unsigned NOT NULL default '0',
  `x` smallint(3) NOT NULL default '0',
  `y` smallint(3) NOT NULL default '0',
  `tid` tinyint(1) unsigned NOT NULL default '0',
  `vid` int(9) unsigned NOT NULL default '0',
  `village` varbinary(255) NOT NULL default '',
  `uid` int(9) NOT NULL default '0',
  `player` varbinary(255) NOT NULL default '',
  `aid` int(9) unsigned NOT NULL default '0',
  `alliance` varbinary(255) NOT NULL default '',
  `population` smallint(5) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `x_world_s3_travian_hk_090813`
--

CREATE TABLE IF NOT EXISTS `x_world_s3_travian_hk_090813` (
  `id` int(9) unsigned NOT NULL default '0',
  `x` smallint(3) NOT NULL default '0',
  `y` smallint(3) NOT NULL default '0',
  `tid` tinyint(1) unsigned NOT NULL default '0',
  `vid` int(9) unsigned NOT NULL default '0',
  `village` varbinary(255) NOT NULL default '',
  `uid` int(9) NOT NULL default '0',
  `player` varbinary(255) NOT NULL default '',
  `aid` int(9) unsigned NOT NULL default '0',
  `alliance` varbinary(255) NOT NULL default '',
  `population` smallint(5) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `x_world_s3_travian_hk_090814`
--

CREATE TABLE IF NOT EXISTS `x_world_s3_travian_hk_090814` (
  `id` int(9) unsigned NOT NULL default '0',
  `x` smallint(3) NOT NULL default '0',
  `y` smallint(3) NOT NULL default '0',
  `tid` tinyint(1) unsigned NOT NULL default '0',
  `vid` int(9) unsigned NOT NULL default '0',
  `village` varbinary(255) NOT NULL default '',
  `uid` int(9) NOT NULL default '0',
  `player` varbinary(255) NOT NULL default '',
  `aid` int(9) unsigned NOT NULL default '0',
  `alliance` varbinary(255) NOT NULL default '',
  `population` smallint(5) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `x_world_s3_travian_hk_090815`
--

CREATE TABLE IF NOT EXISTS `x_world_s3_travian_hk_090815` (
  `id` int(9) unsigned NOT NULL default '0',
  `x` smallint(3) NOT NULL default '0',
  `y` smallint(3) NOT NULL default '0',
  `tid` tinyint(1) unsigned NOT NULL default '0',
  `vid` int(9) unsigned NOT NULL default '0',
  `village` varbinary(255) NOT NULL default '',
  `uid` int(9) NOT NULL default '0',
  `player` varbinary(255) NOT NULL default '',
  `aid` int(9) unsigned NOT NULL default '0',
  `alliance` varbinary(255) NOT NULL default '',
  `population` smallint(5) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `x_world_s3_travian_hk_090816`
--

CREATE TABLE IF NOT EXISTS `x_world_s3_travian_hk_090816` (
  `id` int(9) unsigned NOT NULL default '0',
  `x` smallint(3) NOT NULL default '0',
  `y` smallint(3) NOT NULL default '0',
  `tid` tinyint(1) unsigned NOT NULL default '0',
  `vid` int(9) unsigned NOT NULL default '0',
  `village` varbinary(255) NOT NULL default '',
  `uid` int(9) NOT NULL default '0',
  `player` varbinary(255) NOT NULL default '',
  `aid` int(9) unsigned NOT NULL default '0',
  `alliance` varbinary(255) NOT NULL default '',
  `population` smallint(5) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `x_world_s3_travian_jp_090812`
--

CREATE TABLE IF NOT EXISTS `x_world_s3_travian_jp_090812` (
  `id` int(9) unsigned NOT NULL default '0',
  `x` smallint(3) NOT NULL default '0',
  `y` smallint(3) NOT NULL default '0',
  `tid` tinyint(1) unsigned NOT NULL default '0',
  `vid` int(9) unsigned NOT NULL default '0',
  `village` varbinary(255) NOT NULL default '',
  `uid` int(9) NOT NULL default '0',
  `player` varbinary(255) NOT NULL default '',
  `aid` int(9) unsigned NOT NULL default '0',
  `alliance` varbinary(255) NOT NULL default '',
  `population` smallint(5) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `x_world_s3_travian_jp_090813`
--

CREATE TABLE IF NOT EXISTS `x_world_s3_travian_jp_090813` (
  `id` int(9) unsigned NOT NULL default '0',
  `x` smallint(3) NOT NULL default '0',
  `y` smallint(3) NOT NULL default '0',
  `tid` tinyint(1) unsigned NOT NULL default '0',
  `vid` int(9) unsigned NOT NULL default '0',
  `village` varbinary(255) NOT NULL default '',
  `uid` int(9) NOT NULL default '0',
  `player` varbinary(255) NOT NULL default '',
  `aid` int(9) unsigned NOT NULL default '0',
  `alliance` varbinary(255) NOT NULL default '',
  `population` smallint(5) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `x_world_s3_travian_jp_090814`
--

CREATE TABLE IF NOT EXISTS `x_world_s3_travian_jp_090814` (
  `id` int(9) unsigned NOT NULL default '0',
  `x` smallint(3) NOT NULL default '0',
  `y` smallint(3) NOT NULL default '0',
  `tid` tinyint(1) unsigned NOT NULL default '0',
  `vid` int(9) unsigned NOT NULL default '0',
  `village` varbinary(255) NOT NULL default '',
  `uid` int(9) NOT NULL default '0',
  `player` varbinary(255) NOT NULL default '',
  `aid` int(9) unsigned NOT NULL default '0',
  `alliance` varbinary(255) NOT NULL default '',
  `population` smallint(5) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `x_world_s3_travian_jp_090815`
--

CREATE TABLE IF NOT EXISTS `x_world_s3_travian_jp_090815` (
  `id` int(9) unsigned NOT NULL default '0',
  `x` smallint(3) NOT NULL default '0',
  `y` smallint(3) NOT NULL default '0',
  `tid` tinyint(1) unsigned NOT NULL default '0',
  `vid` int(9) unsigned NOT NULL default '0',
  `village` varbinary(255) NOT NULL default '',
  `uid` int(9) NOT NULL default '0',
  `player` varbinary(255) NOT NULL default '',
  `aid` int(9) unsigned NOT NULL default '0',
  `alliance` varbinary(255) NOT NULL default '',
  `population` smallint(5) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `x_world_s3_travian_jp_090816`
--

CREATE TABLE IF NOT EXISTS `x_world_s3_travian_jp_090816` (
  `id` int(9) unsigned NOT NULL default '0',
  `x` smallint(3) NOT NULL default '0',
  `y` smallint(3) NOT NULL default '0',
  `tid` tinyint(1) unsigned NOT NULL default '0',
  `vid` int(9) unsigned NOT NULL default '0',
  `village` varbinary(255) NOT NULL default '',
  `uid` int(9) NOT NULL default '0',
  `player` varbinary(255) NOT NULL default '',
  `aid` int(9) unsigned NOT NULL default '0',
  `alliance` varbinary(255) NOT NULL default '',
  `population` smallint(5) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `x_world_s3_travian_tw_090812`
--

CREATE TABLE IF NOT EXISTS `x_world_s3_travian_tw_090812` (
  `id` int(9) unsigned NOT NULL default '0',
  `x` smallint(3) NOT NULL default '0',
  `y` smallint(3) NOT NULL default '0',
  `tid` tinyint(1) unsigned NOT NULL default '0',
  `vid` int(9) unsigned NOT NULL default '0',
  `village` varbinary(255) NOT NULL default '',
  `uid` int(9) NOT NULL default '0',
  `player` varbinary(255) NOT NULL default '',
  `aid` int(9) unsigned NOT NULL default '0',
  `alliance` varbinary(255) NOT NULL default '',
  `population` smallint(5) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `x_world_s3_travian_tw_090813`
--

CREATE TABLE IF NOT EXISTS `x_world_s3_travian_tw_090813` (
  `id` int(9) unsigned NOT NULL default '0',
  `x` smallint(3) NOT NULL default '0',
  `y` smallint(3) NOT NULL default '0',
  `tid` tinyint(1) unsigned NOT NULL default '0',
  `vid` int(9) unsigned NOT NULL default '0',
  `village` varbinary(255) NOT NULL default '',
  `uid` int(9) NOT NULL default '0',
  `player` varbinary(255) NOT NULL default '',
  `aid` int(9) unsigned NOT NULL default '0',
  `alliance` varbinary(255) NOT NULL default '',
  `population` smallint(5) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `x_world_s3_travian_tw_090814`
--

CREATE TABLE IF NOT EXISTS `x_world_s3_travian_tw_090814` (
  `id` int(9) unsigned NOT NULL default '0',
  `x` smallint(3) NOT NULL default '0',
  `y` smallint(3) NOT NULL default '0',
  `tid` tinyint(1) unsigned NOT NULL default '0',
  `vid` int(9) unsigned NOT NULL default '0',
  `village` varbinary(255) NOT NULL default '',
  `uid` int(9) NOT NULL default '0',
  `player` varbinary(255) NOT NULL default '',
  `aid` int(9) unsigned NOT NULL default '0',
  `alliance` varbinary(255) NOT NULL default '',
  `population` smallint(5) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `x_world_s3_travian_tw_090815`
--

CREATE TABLE IF NOT EXISTS `x_world_s3_travian_tw_090815` (
  `id` int(9) unsigned NOT NULL default '0',
  `x` smallint(3) NOT NULL default '0',
  `y` smallint(3) NOT NULL default '0',
  `tid` tinyint(1) unsigned NOT NULL default '0',
  `vid` int(9) unsigned NOT NULL default '0',
  `village` varbinary(255) NOT NULL default '',
  `uid` int(9) NOT NULL default '0',
  `player` varbinary(255) NOT NULL default '',
  `aid` int(9) unsigned NOT NULL default '0',
  `alliance` varbinary(255) NOT NULL default '',
  `population` smallint(5) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `x_world_s3_travian_tw_090816`
--

CREATE TABLE IF NOT EXISTS `x_world_s3_travian_tw_090816` (
  `id` int(9) unsigned NOT NULL default '0',
  `x` smallint(3) NOT NULL default '0',
  `y` smallint(3) NOT NULL default '0',
  `tid` tinyint(1) unsigned NOT NULL default '0',
  `vid` int(9) unsigned NOT NULL default '0',
  `village` varbinary(255) NOT NULL default '',
  `uid` int(9) NOT NULL default '0',
  `player` varbinary(255) NOT NULL default '',
  `aid` int(9) unsigned NOT NULL default '0',
  `alliance` varbinary(255) NOT NULL default '',
  `population` smallint(5) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `x_world_s4_travian_com_090812`
--

CREATE TABLE IF NOT EXISTS `x_world_s4_travian_com_090812` (
  `id` int(9) unsigned NOT NULL default '0',
  `x` smallint(3) NOT NULL default '0',
  `y` smallint(3) NOT NULL default '0',
  `tid` tinyint(1) unsigned NOT NULL default '0',
  `vid` int(9) unsigned NOT NULL default '0',
  `village` varbinary(255) NOT NULL default '',
  `uid` int(9) NOT NULL default '0',
  `player` varbinary(255) NOT NULL default '',
  `aid` int(9) unsigned NOT NULL default '0',
  `alliance` varbinary(255) NOT NULL default '',
  `population` smallint(5) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `x_world_s4_travian_com_090813`
--

CREATE TABLE IF NOT EXISTS `x_world_s4_travian_com_090813` (
  `id` int(9) unsigned NOT NULL default '0',
  `x` smallint(3) NOT NULL default '0',
  `y` smallint(3) NOT NULL default '0',
  `tid` tinyint(1) unsigned NOT NULL default '0',
  `vid` int(9) unsigned NOT NULL default '0',
  `village` varbinary(255) NOT NULL default '',
  `uid` int(9) NOT NULL default '0',
  `player` varbinary(255) NOT NULL default '',
  `aid` int(9) unsigned NOT NULL default '0',
  `alliance` varbinary(255) NOT NULL default '',
  `population` smallint(5) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `x_world_s4_travian_com_090814`
--

CREATE TABLE IF NOT EXISTS `x_world_s4_travian_com_090814` (
  `id` int(9) unsigned NOT NULL default '0',
  `x` smallint(3) NOT NULL default '0',
  `y` smallint(3) NOT NULL default '0',
  `tid` tinyint(1) unsigned NOT NULL default '0',
  `vid` int(9) unsigned NOT NULL default '0',
  `village` varbinary(255) NOT NULL default '',
  `uid` int(9) NOT NULL default '0',
  `player` varbinary(255) NOT NULL default '',
  `aid` int(9) unsigned NOT NULL default '0',
  `alliance` varbinary(255) NOT NULL default '',
  `population` smallint(5) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `x_world_s4_travian_com_090815`
--

CREATE TABLE IF NOT EXISTS `x_world_s4_travian_com_090815` (
  `id` int(9) unsigned NOT NULL default '0',
  `x` smallint(3) NOT NULL default '0',
  `y` smallint(3) NOT NULL default '0',
  `tid` tinyint(1) unsigned NOT NULL default '0',
  `vid` int(9) unsigned NOT NULL default '0',
  `village` varbinary(255) NOT NULL default '',
  `uid` int(9) NOT NULL default '0',
  `player` varbinary(255) NOT NULL default '',
  `aid` int(9) unsigned NOT NULL default '0',
  `alliance` varbinary(255) NOT NULL default '',
  `population` smallint(5) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `x_world_s4_travian_com_090816`
--

CREATE TABLE IF NOT EXISTS `x_world_s4_travian_com_090816` (
  `id` int(9) unsigned NOT NULL default '0',
  `x` smallint(3) NOT NULL default '0',
  `y` smallint(3) NOT NULL default '0',
  `tid` tinyint(1) unsigned NOT NULL default '0',
  `vid` int(9) unsigned NOT NULL default '0',
  `village` varbinary(255) NOT NULL default '',
  `uid` int(9) NOT NULL default '0',
  `player` varbinary(255) NOT NULL default '',
  `aid` int(9) unsigned NOT NULL default '0',
  `alliance` varbinary(255) NOT NULL default '',
  `population` smallint(5) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `x_world_s4_travian_hk_090812`
--

CREATE TABLE IF NOT EXISTS `x_world_s4_travian_hk_090812` (
  `id` int(9) unsigned NOT NULL default '0',
  `x` smallint(3) NOT NULL default '0',
  `y` smallint(3) NOT NULL default '0',
  `tid` tinyint(1) unsigned NOT NULL default '0',
  `vid` int(9) unsigned NOT NULL default '0',
  `village` varbinary(255) NOT NULL default '',
  `uid` int(9) NOT NULL default '0',
  `player` varbinary(255) NOT NULL default '',
  `aid` int(9) unsigned NOT NULL default '0',
  `alliance` varbinary(255) NOT NULL default '',
  `population` smallint(5) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `x_world_s4_travian_hk_090813`
--

CREATE TABLE IF NOT EXISTS `x_world_s4_travian_hk_090813` (
  `id` int(9) unsigned NOT NULL default '0',
  `x` smallint(3) NOT NULL default '0',
  `y` smallint(3) NOT NULL default '0',
  `tid` tinyint(1) unsigned NOT NULL default '0',
  `vid` int(9) unsigned NOT NULL default '0',
  `village` varbinary(255) NOT NULL default '',
  `uid` int(9) NOT NULL default '0',
  `player` varbinary(255) NOT NULL default '',
  `aid` int(9) unsigned NOT NULL default '0',
  `alliance` varbinary(255) NOT NULL default '',
  `population` smallint(5) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `x_world_s4_travian_hk_090814`
--

CREATE TABLE IF NOT EXISTS `x_world_s4_travian_hk_090814` (
  `id` int(9) unsigned NOT NULL default '0',
  `x` smallint(3) NOT NULL default '0',
  `y` smallint(3) NOT NULL default '0',
  `tid` tinyint(1) unsigned NOT NULL default '0',
  `vid` int(9) unsigned NOT NULL default '0',
  `village` varbinary(255) NOT NULL default '',
  `uid` int(9) NOT NULL default '0',
  `player` varbinary(255) NOT NULL default '',
  `aid` int(9) unsigned NOT NULL default '0',
  `alliance` varbinary(255) NOT NULL default '',
  `population` smallint(5) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `x_world_s4_travian_hk_090815`
--

CREATE TABLE IF NOT EXISTS `x_world_s4_travian_hk_090815` (
  `id` int(9) unsigned NOT NULL default '0',
  `x` smallint(3) NOT NULL default '0',
  `y` smallint(3) NOT NULL default '0',
  `tid` tinyint(1) unsigned NOT NULL default '0',
  `vid` int(9) unsigned NOT NULL default '0',
  `village` varbinary(255) NOT NULL default '',
  `uid` int(9) NOT NULL default '0',
  `player` varbinary(255) NOT NULL default '',
  `aid` int(9) unsigned NOT NULL default '0',
  `alliance` varbinary(255) NOT NULL default '',
  `population` smallint(5) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `x_world_s4_travian_hk_090816`
--

CREATE TABLE IF NOT EXISTS `x_world_s4_travian_hk_090816` (
  `id` int(9) unsigned NOT NULL default '0',
  `x` smallint(3) NOT NULL default '0',
  `y` smallint(3) NOT NULL default '0',
  `tid` tinyint(1) unsigned NOT NULL default '0',
  `vid` int(9) unsigned NOT NULL default '0',
  `village` varbinary(255) NOT NULL default '',
  `uid` int(9) NOT NULL default '0',
  `player` varbinary(255) NOT NULL default '',
  `aid` int(9) unsigned NOT NULL default '0',
  `alliance` varbinary(255) NOT NULL default '',
  `population` smallint(5) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `x_world_s4_travian_jp_090812`
--

CREATE TABLE IF NOT EXISTS `x_world_s4_travian_jp_090812` (
  `id` int(9) unsigned NOT NULL default '0',
  `x` smallint(3) NOT NULL default '0',
  `y` smallint(3) NOT NULL default '0',
  `tid` tinyint(1) unsigned NOT NULL default '0',
  `vid` int(9) unsigned NOT NULL default '0',
  `village` varbinary(255) NOT NULL default '',
  `uid` int(9) NOT NULL default '0',
  `player` varbinary(255) NOT NULL default '',
  `aid` int(9) unsigned NOT NULL default '0',
  `alliance` varbinary(255) NOT NULL default '',
  `population` smallint(5) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `x_world_s4_travian_jp_090813`
--

CREATE TABLE IF NOT EXISTS `x_world_s4_travian_jp_090813` (
  `id` int(9) unsigned NOT NULL default '0',
  `x` smallint(3) NOT NULL default '0',
  `y` smallint(3) NOT NULL default '0',
  `tid` tinyint(1) unsigned NOT NULL default '0',
  `vid` int(9) unsigned NOT NULL default '0',
  `village` varbinary(255) NOT NULL default '',
  `uid` int(9) NOT NULL default '0',
  `player` varbinary(255) NOT NULL default '',
  `aid` int(9) unsigned NOT NULL default '0',
  `alliance` varbinary(255) NOT NULL default '',
  `population` smallint(5) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `x_world_s4_travian_jp_090814`
--

CREATE TABLE IF NOT EXISTS `x_world_s4_travian_jp_090814` (
  `id` int(9) unsigned NOT NULL default '0',
  `x` smallint(3) NOT NULL default '0',
  `y` smallint(3) NOT NULL default '0',
  `tid` tinyint(1) unsigned NOT NULL default '0',
  `vid` int(9) unsigned NOT NULL default '0',
  `village` varbinary(255) NOT NULL default '',
  `uid` int(9) NOT NULL default '0',
  `player` varbinary(255) NOT NULL default '',
  `aid` int(9) unsigned NOT NULL default '0',
  `alliance` varbinary(255) NOT NULL default '',
  `population` smallint(5) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `x_world_s4_travian_jp_090815`
--

CREATE TABLE IF NOT EXISTS `x_world_s4_travian_jp_090815` (
  `id` int(9) unsigned NOT NULL default '0',
  `x` smallint(3) NOT NULL default '0',
  `y` smallint(3) NOT NULL default '0',
  `tid` tinyint(1) unsigned NOT NULL default '0',
  `vid` int(9) unsigned NOT NULL default '0',
  `village` varbinary(255) NOT NULL default '',
  `uid` int(9) NOT NULL default '0',
  `player` varbinary(255) NOT NULL default '',
  `aid` int(9) unsigned NOT NULL default '0',
  `alliance` varbinary(255) NOT NULL default '',
  `population` smallint(5) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `x_world_s4_travian_jp_090816`
--

CREATE TABLE IF NOT EXISTS `x_world_s4_travian_jp_090816` (
  `id` int(9) unsigned NOT NULL default '0',
  `x` smallint(3) NOT NULL default '0',
  `y` smallint(3) NOT NULL default '0',
  `tid` tinyint(1) unsigned NOT NULL default '0',
  `vid` int(9) unsigned NOT NULL default '0',
  `village` varbinary(255) NOT NULL default '',
  `uid` int(9) NOT NULL default '0',
  `player` varbinary(255) NOT NULL default '',
  `aid` int(9) unsigned NOT NULL default '0',
  `alliance` varbinary(255) NOT NULL default '',
  `population` smallint(5) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `x_world_s4_travian_tw_090812`
--

CREATE TABLE IF NOT EXISTS `x_world_s4_travian_tw_090812` (
  `id` int(9) unsigned NOT NULL default '0',
  `x` smallint(3) NOT NULL default '0',
  `y` smallint(3) NOT NULL default '0',
  `tid` tinyint(1) unsigned NOT NULL default '0',
  `vid` int(9) unsigned NOT NULL default '0',
  `village` varbinary(255) NOT NULL default '',
  `uid` int(9) NOT NULL default '0',
  `player` varbinary(255) NOT NULL default '',
  `aid` int(9) unsigned NOT NULL default '0',
  `alliance` varbinary(255) NOT NULL default '',
  `population` smallint(5) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `x_world_s4_travian_tw_090813`
--

CREATE TABLE IF NOT EXISTS `x_world_s4_travian_tw_090813` (
  `id` int(9) unsigned NOT NULL default '0',
  `x` smallint(3) NOT NULL default '0',
  `y` smallint(3) NOT NULL default '0',
  `tid` tinyint(1) unsigned NOT NULL default '0',
  `vid` int(9) unsigned NOT NULL default '0',
  `village` varbinary(255) NOT NULL default '',
  `uid` int(9) NOT NULL default '0',
  `player` varbinary(255) NOT NULL default '',
  `aid` int(9) unsigned NOT NULL default '0',
  `alliance` varbinary(255) NOT NULL default '',
  `population` smallint(5) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `x_world_s4_travian_tw_090814`
--

CREATE TABLE IF NOT EXISTS `x_world_s4_travian_tw_090814` (
  `id` int(9) unsigned NOT NULL default '0',
  `x` smallint(3) NOT NULL default '0',
  `y` smallint(3) NOT NULL default '0',
  `tid` tinyint(1) unsigned NOT NULL default '0',
  `vid` int(9) unsigned NOT NULL default '0',
  `village` varbinary(255) NOT NULL default '',
  `uid` int(9) NOT NULL default '0',
  `player` varbinary(255) NOT NULL default '',
  `aid` int(9) unsigned NOT NULL default '0',
  `alliance` varbinary(255) NOT NULL default '',
  `population` smallint(5) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `x_world_s4_travian_tw_090815`
--

CREATE TABLE IF NOT EXISTS `x_world_s4_travian_tw_090815` (
  `id` int(9) unsigned NOT NULL default '0',
  `x` smallint(3) NOT NULL default '0',
  `y` smallint(3) NOT NULL default '0',
  `tid` tinyint(1) unsigned NOT NULL default '0',
  `vid` int(9) unsigned NOT NULL default '0',
  `village` varbinary(255) NOT NULL default '',
  `uid` int(9) NOT NULL default '0',
  `player` varbinary(255) NOT NULL default '',
  `aid` int(9) unsigned NOT NULL default '0',
  `alliance` varbinary(255) NOT NULL default '',
  `population` smallint(5) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `x_world_s4_travian_tw_090816`
--

CREATE TABLE IF NOT EXISTS `x_world_s4_travian_tw_090816` (
  `id` int(9) unsigned NOT NULL default '0',
  `x` smallint(3) NOT NULL default '0',
  `y` smallint(3) NOT NULL default '0',
  `tid` tinyint(1) unsigned NOT NULL default '0',
  `vid` int(9) unsigned NOT NULL default '0',
  `village` varbinary(255) NOT NULL default '',
  `uid` int(9) NOT NULL default '0',
  `player` varbinary(255) NOT NULL default '',
  `aid` int(9) unsigned NOT NULL default '0',
  `alliance` varbinary(255) NOT NULL default '',
  `population` smallint(5) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `x_world_s5_travian_hk_090812`
--

CREATE TABLE IF NOT EXISTS `x_world_s5_travian_hk_090812` (
  `id` int(9) unsigned NOT NULL default '0',
  `x` smallint(3) NOT NULL default '0',
  `y` smallint(3) NOT NULL default '0',
  `tid` tinyint(1) unsigned NOT NULL default '0',
  `vid` int(9) unsigned NOT NULL default '0',
  `village` varbinary(255) NOT NULL default '',
  `uid` int(9) NOT NULL default '0',
  `player` varbinary(255) NOT NULL default '',
  `aid` int(9) unsigned NOT NULL default '0',
  `alliance` varbinary(255) NOT NULL default '',
  `population` smallint(5) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `x_world_s5_travian_hk_090813`
--

CREATE TABLE IF NOT EXISTS `x_world_s5_travian_hk_090813` (
  `id` int(9) unsigned NOT NULL default '0',
  `x` smallint(3) NOT NULL default '0',
  `y` smallint(3) NOT NULL default '0',
  `tid` tinyint(1) unsigned NOT NULL default '0',
  `vid` int(9) unsigned NOT NULL default '0',
  `village` varbinary(255) NOT NULL default '',
  `uid` int(9) NOT NULL default '0',
  `player` varbinary(255) NOT NULL default '',
  `aid` int(9) unsigned NOT NULL default '0',
  `alliance` varbinary(255) NOT NULL default '',
  `population` smallint(5) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `x_world_s5_travian_hk_090814`
--

CREATE TABLE IF NOT EXISTS `x_world_s5_travian_hk_090814` (
  `id` int(9) unsigned NOT NULL default '0',
  `x` smallint(3) NOT NULL default '0',
  `y` smallint(3) NOT NULL default '0',
  `tid` tinyint(1) unsigned NOT NULL default '0',
  `vid` int(9) unsigned NOT NULL default '0',
  `village` varbinary(255) NOT NULL default '',
  `uid` int(9) NOT NULL default '0',
  `player` varbinary(255) NOT NULL default '',
  `aid` int(9) unsigned NOT NULL default '0',
  `alliance` varbinary(255) NOT NULL default '',
  `population` smallint(5) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `x_world_s5_travian_hk_090815`
--

CREATE TABLE IF NOT EXISTS `x_world_s5_travian_hk_090815` (
  `id` int(9) unsigned NOT NULL default '0',
  `x` smallint(3) NOT NULL default '0',
  `y` smallint(3) NOT NULL default '0',
  `tid` tinyint(1) unsigned NOT NULL default '0',
  `vid` int(9) unsigned NOT NULL default '0',
  `village` varbinary(255) NOT NULL default '',
  `uid` int(9) NOT NULL default '0',
  `player` varbinary(255) NOT NULL default '',
  `aid` int(9) unsigned NOT NULL default '0',
  `alliance` varbinary(255) NOT NULL default '',
  `population` smallint(5) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `x_world_s5_travian_hk_090816`
--

CREATE TABLE IF NOT EXISTS `x_world_s5_travian_hk_090816` (
  `id` int(9) unsigned NOT NULL default '0',
  `x` smallint(3) NOT NULL default '0',
  `y` smallint(3) NOT NULL default '0',
  `tid` tinyint(1) unsigned NOT NULL default '0',
  `vid` int(9) unsigned NOT NULL default '0',
  `village` varbinary(255) NOT NULL default '',
  `uid` int(9) NOT NULL default '0',
  `player` varbinary(255) NOT NULL default '',
  `aid` int(9) unsigned NOT NULL default '0',
  `alliance` varbinary(255) NOT NULL default '',
  `population` smallint(5) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `x_world_s5_travian_jp_090812`
--

CREATE TABLE IF NOT EXISTS `x_world_s5_travian_jp_090812` (
  `id` int(9) unsigned NOT NULL default '0',
  `x` smallint(3) NOT NULL default '0',
  `y` smallint(3) NOT NULL default '0',
  `tid` tinyint(1) unsigned NOT NULL default '0',
  `vid` int(9) unsigned NOT NULL default '0',
  `village` varbinary(255) NOT NULL default '',
  `uid` int(9) NOT NULL default '0',
  `player` varbinary(255) NOT NULL default '',
  `aid` int(9) unsigned NOT NULL default '0',
  `alliance` varbinary(255) NOT NULL default '',
  `population` smallint(5) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `x_world_s5_travian_jp_090813`
--

CREATE TABLE IF NOT EXISTS `x_world_s5_travian_jp_090813` (
  `id` int(9) unsigned NOT NULL default '0',
  `x` smallint(3) NOT NULL default '0',
  `y` smallint(3) NOT NULL default '0',
  `tid` tinyint(1) unsigned NOT NULL default '0',
  `vid` int(9) unsigned NOT NULL default '0',
  `village` varbinary(255) NOT NULL default '',
  `uid` int(9) NOT NULL default '0',
  `player` varbinary(255) NOT NULL default '',
  `aid` int(9) unsigned NOT NULL default '0',
  `alliance` varbinary(255) NOT NULL default '',
  `population` smallint(5) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `x_world_s5_travian_jp_090814`
--

CREATE TABLE IF NOT EXISTS `x_world_s5_travian_jp_090814` (
  `id` int(9) unsigned NOT NULL default '0',
  `x` smallint(3) NOT NULL default '0',
  `y` smallint(3) NOT NULL default '0',
  `tid` tinyint(1) unsigned NOT NULL default '0',
  `vid` int(9) unsigned NOT NULL default '0',
  `village` varbinary(255) NOT NULL default '',
  `uid` int(9) NOT NULL default '0',
  `player` varbinary(255) NOT NULL default '',
  `aid` int(9) unsigned NOT NULL default '0',
  `alliance` varbinary(255) NOT NULL default '',
  `population` smallint(5) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `x_world_s5_travian_jp_090815`
--

CREATE TABLE IF NOT EXISTS `x_world_s5_travian_jp_090815` (
  `id` int(9) unsigned NOT NULL default '0',
  `x` smallint(3) NOT NULL default '0',
  `y` smallint(3) NOT NULL default '0',
  `tid` tinyint(1) unsigned NOT NULL default '0',
  `vid` int(9) unsigned NOT NULL default '0',
  `village` varbinary(255) NOT NULL default '',
  `uid` int(9) NOT NULL default '0',
  `player` varbinary(255) NOT NULL default '',
  `aid` int(9) unsigned NOT NULL default '0',
  `alliance` varbinary(255) NOT NULL default '',
  `population` smallint(5) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `x_world_s5_travian_jp_090816`
--

CREATE TABLE IF NOT EXISTS `x_world_s5_travian_jp_090816` (
  `id` int(9) unsigned NOT NULL default '0',
  `x` smallint(3) NOT NULL default '0',
  `y` smallint(3) NOT NULL default '0',
  `tid` tinyint(1) unsigned NOT NULL default '0',
  `vid` int(9) unsigned NOT NULL default '0',
  `village` varbinary(255) NOT NULL default '',
  `uid` int(9) NOT NULL default '0',
  `player` varbinary(255) NOT NULL default '',
  `aid` int(9) unsigned NOT NULL default '0',
  `alliance` varbinary(255) NOT NULL default '',
  `population` smallint(5) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `x_world_s5_travian_tw_090812`
--

CREATE TABLE IF NOT EXISTS `x_world_s5_travian_tw_090812` (
  `id` int(9) unsigned NOT NULL default '0',
  `x` smallint(3) NOT NULL default '0',
  `y` smallint(3) NOT NULL default '0',
  `tid` tinyint(1) unsigned NOT NULL default '0',
  `vid` int(9) unsigned NOT NULL default '0',
  `village` varbinary(255) NOT NULL default '',
  `uid` int(9) NOT NULL default '0',
  `player` varbinary(255) NOT NULL default '',
  `aid` int(9) unsigned NOT NULL default '0',
  `alliance` varbinary(255) NOT NULL default '',
  `population` smallint(5) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `x_world_s5_travian_tw_090813`
--

CREATE TABLE IF NOT EXISTS `x_world_s5_travian_tw_090813` (
  `id` int(9) unsigned NOT NULL default '0',
  `x` smallint(3) NOT NULL default '0',
  `y` smallint(3) NOT NULL default '0',
  `tid` tinyint(1) unsigned NOT NULL default '0',
  `vid` int(9) unsigned NOT NULL default '0',
  `village` varbinary(255) NOT NULL default '',
  `uid` int(9) NOT NULL default '0',
  `player` varbinary(255) NOT NULL default '',
  `aid` int(9) unsigned NOT NULL default '0',
  `alliance` varbinary(255) NOT NULL default '',
  `population` smallint(5) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `x_world_s5_travian_tw_090814`
--

CREATE TABLE IF NOT EXISTS `x_world_s5_travian_tw_090814` (
  `id` int(9) unsigned NOT NULL default '0',
  `x` smallint(3) NOT NULL default '0',
  `y` smallint(3) NOT NULL default '0',
  `tid` tinyint(1) unsigned NOT NULL default '0',
  `vid` int(9) unsigned NOT NULL default '0',
  `village` varbinary(255) NOT NULL default '',
  `uid` int(9) NOT NULL default '0',
  `player` varbinary(255) NOT NULL default '',
  `aid` int(9) unsigned NOT NULL default '0',
  `alliance` varbinary(255) NOT NULL default '',
  `population` smallint(5) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `x_world_s5_travian_tw_090815`
--

CREATE TABLE IF NOT EXISTS `x_world_s5_travian_tw_090815` (
  `id` int(9) unsigned NOT NULL default '0',
  `x` smallint(3) NOT NULL default '0',
  `y` smallint(3) NOT NULL default '0',
  `tid` tinyint(1) unsigned NOT NULL default '0',
  `vid` int(9) unsigned NOT NULL default '0',
  `village` varbinary(255) NOT NULL default '',
  `uid` int(9) NOT NULL default '0',
  `player` varbinary(255) NOT NULL default '',
  `aid` int(9) unsigned NOT NULL default '0',
  `alliance` varbinary(255) NOT NULL default '',
  `population` smallint(5) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `x_world_s5_travian_tw_090816`
--

CREATE TABLE IF NOT EXISTS `x_world_s5_travian_tw_090816` (
  `id` int(9) unsigned NOT NULL default '0',
  `x` smallint(3) NOT NULL default '0',
  `y` smallint(3) NOT NULL default '0',
  `tid` tinyint(1) unsigned NOT NULL default '0',
  `vid` int(9) unsigned NOT NULL default '0',
  `village` varbinary(255) NOT NULL default '',
  `uid` int(9) NOT NULL default '0',
  `player` varbinary(255) NOT NULL default '',
  `aid` int(9) unsigned NOT NULL default '0',
  `alliance` varbinary(255) NOT NULL default '',
  `population` smallint(5) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `x_world_s6_travian_hk_090812`
--

CREATE TABLE IF NOT EXISTS `x_world_s6_travian_hk_090812` (
  `id` int(9) unsigned NOT NULL default '0',
  `x` smallint(3) NOT NULL default '0',
  `y` smallint(3) NOT NULL default '0',
  `tid` tinyint(1) unsigned NOT NULL default '0',
  `vid` int(9) unsigned NOT NULL default '0',
  `village` varbinary(255) NOT NULL default '',
  `uid` int(9) NOT NULL default '0',
  `player` varbinary(255) NOT NULL default '',
  `aid` int(9) unsigned NOT NULL default '0',
  `alliance` varbinary(255) NOT NULL default '',
  `population` smallint(5) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `x_world_s6_travian_hk_090813`
--

CREATE TABLE IF NOT EXISTS `x_world_s6_travian_hk_090813` (
  `id` int(9) unsigned NOT NULL default '0',
  `x` smallint(3) NOT NULL default '0',
  `y` smallint(3) NOT NULL default '0',
  `tid` tinyint(1) unsigned NOT NULL default '0',
  `vid` int(9) unsigned NOT NULL default '0',
  `village` varbinary(255) NOT NULL default '',
  `uid` int(9) NOT NULL default '0',
  `player` varbinary(255) NOT NULL default '',
  `aid` int(9) unsigned NOT NULL default '0',
  `alliance` varbinary(255) NOT NULL default '',
  `population` smallint(5) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `x_world_s6_travian_hk_090814`
--

CREATE TABLE IF NOT EXISTS `x_world_s6_travian_hk_090814` (
  `id` int(9) unsigned NOT NULL default '0',
  `x` smallint(3) NOT NULL default '0',
  `y` smallint(3) NOT NULL default '0',
  `tid` tinyint(1) unsigned NOT NULL default '0',
  `vid` int(9) unsigned NOT NULL default '0',
  `village` varbinary(255) NOT NULL default '',
  `uid` int(9) NOT NULL default '0',
  `player` varbinary(255) NOT NULL default '',
  `aid` int(9) unsigned NOT NULL default '0',
  `alliance` varbinary(255) NOT NULL default '',
  `population` smallint(5) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `x_world_s6_travian_hk_090815`
--

CREATE TABLE IF NOT EXISTS `x_world_s6_travian_hk_090815` (
  `id` int(9) unsigned NOT NULL default '0',
  `x` smallint(3) NOT NULL default '0',
  `y` smallint(3) NOT NULL default '0',
  `tid` tinyint(1) unsigned NOT NULL default '0',
  `vid` int(9) unsigned NOT NULL default '0',
  `village` varbinary(255) NOT NULL default '',
  `uid` int(9) NOT NULL default '0',
  `player` varbinary(255) NOT NULL default '',
  `aid` int(9) unsigned NOT NULL default '0',
  `alliance` varbinary(255) NOT NULL default '',
  `population` smallint(5) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `x_world_s6_travian_hk_090816`
--

CREATE TABLE IF NOT EXISTS `x_world_s6_travian_hk_090816` (
  `id` int(9) unsigned NOT NULL default '0',
  `x` smallint(3) NOT NULL default '0',
  `y` smallint(3) NOT NULL default '0',
  `tid` tinyint(1) unsigned NOT NULL default '0',
  `vid` int(9) unsigned NOT NULL default '0',
  `village` varbinary(255) NOT NULL default '',
  `uid` int(9) NOT NULL default '0',
  `player` varbinary(255) NOT NULL default '',
  `aid` int(9) unsigned NOT NULL default '0',
  `alliance` varbinary(255) NOT NULL default '',
  `population` smallint(5) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `x_world_s6_travian_tw_090812`
--

CREATE TABLE IF NOT EXISTS `x_world_s6_travian_tw_090812` (
  `id` int(9) unsigned NOT NULL default '0',
  `x` smallint(3) NOT NULL default '0',
  `y` smallint(3) NOT NULL default '0',
  `tid` tinyint(1) unsigned NOT NULL default '0',
  `vid` int(9) unsigned NOT NULL default '0',
  `village` varbinary(255) NOT NULL default '',
  `uid` int(9) NOT NULL default '0',
  `player` varbinary(255) NOT NULL default '',
  `aid` int(9) unsigned NOT NULL default '0',
  `alliance` varbinary(255) NOT NULL default '',
  `population` smallint(5) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `x_world_s6_travian_tw_090813`
--

CREATE TABLE IF NOT EXISTS `x_world_s6_travian_tw_090813` (
  `id` int(9) unsigned NOT NULL default '0',
  `x` smallint(3) NOT NULL default '0',
  `y` smallint(3) NOT NULL default '0',
  `tid` tinyint(1) unsigned NOT NULL default '0',
  `vid` int(9) unsigned NOT NULL default '0',
  `village` varbinary(255) NOT NULL default '',
  `uid` int(9) NOT NULL default '0',
  `player` varbinary(255) NOT NULL default '',
  `aid` int(9) unsigned NOT NULL default '0',
  `alliance` varbinary(255) NOT NULL default '',
  `population` smallint(5) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `x_world_s6_travian_tw_090814`
--

CREATE TABLE IF NOT EXISTS `x_world_s6_travian_tw_090814` (
  `id` int(9) unsigned NOT NULL default '0',
  `x` smallint(3) NOT NULL default '0',
  `y` smallint(3) NOT NULL default '0',
  `tid` tinyint(1) unsigned NOT NULL default '0',
  `vid` int(9) unsigned NOT NULL default '0',
  `village` varbinary(255) NOT NULL default '',
  `uid` int(9) NOT NULL default '0',
  `player` varbinary(255) NOT NULL default '',
  `aid` int(9) unsigned NOT NULL default '0',
  `alliance` varbinary(255) NOT NULL default '',
  `population` smallint(5) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `x_world_s6_travian_tw_090815`
--

CREATE TABLE IF NOT EXISTS `x_world_s6_travian_tw_090815` (
  `id` int(9) unsigned NOT NULL default '0',
  `x` smallint(3) NOT NULL default '0',
  `y` smallint(3) NOT NULL default '0',
  `tid` tinyint(1) unsigned NOT NULL default '0',
  `vid` int(9) unsigned NOT NULL default '0',
  `village` varbinary(255) NOT NULL default '',
  `uid` int(9) NOT NULL default '0',
  `player` varbinary(255) NOT NULL default '',
  `aid` int(9) unsigned NOT NULL default '0',
  `alliance` varbinary(255) NOT NULL default '',
  `population` smallint(5) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `x_world_s6_travian_tw_090816`
--

CREATE TABLE IF NOT EXISTS `x_world_s6_travian_tw_090816` (
  `id` int(9) unsigned NOT NULL default '0',
  `x` smallint(3) NOT NULL default '0',
  `y` smallint(3) NOT NULL default '0',
  `tid` tinyint(1) unsigned NOT NULL default '0',
  `vid` int(9) unsigned NOT NULL default '0',
  `village` varbinary(255) NOT NULL default '',
  `uid` int(9) NOT NULL default '0',
  `player` varbinary(255) NOT NULL default '',
  `aid` int(9) unsigned NOT NULL default '0',
  `alliance` varbinary(255) NOT NULL default '',
  `population` smallint(5) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `x_world_speed2_travian_cn_090812`
--

CREATE TABLE IF NOT EXISTS `x_world_speed2_travian_cn_090812` (
  `id` int(9) unsigned NOT NULL default '0',
  `x` smallint(3) NOT NULL default '0',
  `y` smallint(3) NOT NULL default '0',
  `tid` tinyint(1) unsigned NOT NULL default '0',
  `vid` int(9) unsigned NOT NULL default '0',
  `village` varbinary(255) NOT NULL default '',
  `uid` int(9) NOT NULL default '0',
  `player` varbinary(255) NOT NULL default '',
  `aid` int(9) unsigned NOT NULL default '0',
  `alliance` varbinary(255) NOT NULL default '',
  `population` smallint(5) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `x_world_speed2_travian_cn_090813`
--

CREATE TABLE IF NOT EXISTS `x_world_speed2_travian_cn_090813` (
  `id` int(9) unsigned NOT NULL default '0',
  `x` smallint(3) NOT NULL default '0',
  `y` smallint(3) NOT NULL default '0',
  `tid` tinyint(1) unsigned NOT NULL default '0',
  `vid` int(9) unsigned NOT NULL default '0',
  `village` varbinary(255) NOT NULL default '',
  `uid` int(9) NOT NULL default '0',
  `player` varbinary(255) NOT NULL default '',
  `aid` int(9) unsigned NOT NULL default '0',
  `alliance` varbinary(255) NOT NULL default '',
  `population` smallint(5) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `x_world_speed2_travian_cn_090814`
--

CREATE TABLE IF NOT EXISTS `x_world_speed2_travian_cn_090814` (
  `id` int(9) unsigned NOT NULL default '0',
  `x` smallint(3) NOT NULL default '0',
  `y` smallint(3) NOT NULL default '0',
  `tid` tinyint(1) unsigned NOT NULL default '0',
  `vid` int(9) unsigned NOT NULL default '0',
  `village` varbinary(255) NOT NULL default '',
  `uid` int(9) NOT NULL default '0',
  `player` varbinary(255) NOT NULL default '',
  `aid` int(9) unsigned NOT NULL default '0',
  `alliance` varbinary(255) NOT NULL default '',
  `population` smallint(5) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `x_world_speed2_travian_cn_090815`
--

CREATE TABLE IF NOT EXISTS `x_world_speed2_travian_cn_090815` (
  `id` int(9) unsigned NOT NULL default '0',
  `x` smallint(3) NOT NULL default '0',
  `y` smallint(3) NOT NULL default '0',
  `tid` tinyint(1) unsigned NOT NULL default '0',
  `vid` int(9) unsigned NOT NULL default '0',
  `village` varbinary(255) NOT NULL default '',
  `uid` int(9) NOT NULL default '0',
  `player` varbinary(255) NOT NULL default '',
  `aid` int(9) unsigned NOT NULL default '0',
  `alliance` varbinary(255) NOT NULL default '',
  `population` smallint(5) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `x_world_speed2_travian_cn_090816`
--

CREATE TABLE IF NOT EXISTS `x_world_speed2_travian_cn_090816` (
  `id` int(9) unsigned NOT NULL default '0',
  `x` smallint(3) NOT NULL default '0',
  `y` smallint(3) NOT NULL default '0',
  `tid` tinyint(1) unsigned NOT NULL default '0',
  `vid` int(9) unsigned NOT NULL default '0',
  `village` varbinary(255) NOT NULL default '',
  `uid` int(9) NOT NULL default '0',
  `player` varbinary(255) NOT NULL default '',
  `aid` int(9) unsigned NOT NULL default '0',
  `alliance` varbinary(255) NOT NULL default '',
  `population` smallint(5) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `x_world_speed_travian_hk_090812`
--

CREATE TABLE IF NOT EXISTS `x_world_speed_travian_hk_090812` (
  `id` int(9) unsigned NOT NULL default '0',
  `x` smallint(3) NOT NULL default '0',
  `y` smallint(3) NOT NULL default '0',
  `tid` tinyint(1) unsigned NOT NULL default '0',
  `vid` int(9) unsigned NOT NULL default '0',
  `village` varbinary(255) NOT NULL default '',
  `uid` int(9) NOT NULL default '0',
  `player` varbinary(255) NOT NULL default '',
  `aid` int(9) unsigned NOT NULL default '0',
  `alliance` varbinary(255) NOT NULL default '',
  `population` smallint(5) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `x_world_speed_travian_hk_090813`
--

CREATE TABLE IF NOT EXISTS `x_world_speed_travian_hk_090813` (
  `id` int(9) unsigned NOT NULL default '0',
  `x` smallint(3) NOT NULL default '0',
  `y` smallint(3) NOT NULL default '0',
  `tid` tinyint(1) unsigned NOT NULL default '0',
  `vid` int(9) unsigned NOT NULL default '0',
  `village` varbinary(255) NOT NULL default '',
  `uid` int(9) NOT NULL default '0',
  `player` varbinary(255) NOT NULL default '',
  `aid` int(9) unsigned NOT NULL default '0',
  `alliance` varbinary(255) NOT NULL default '',
  `population` smallint(5) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `x_world_speed_travian_hk_090814`
--

CREATE TABLE IF NOT EXISTS `x_world_speed_travian_hk_090814` (
  `id` int(9) unsigned NOT NULL default '0',
  `x` smallint(3) NOT NULL default '0',
  `y` smallint(3) NOT NULL default '0',
  `tid` tinyint(1) unsigned NOT NULL default '0',
  `vid` int(9) unsigned NOT NULL default '0',
  `village` varbinary(255) NOT NULL default '',
  `uid` int(9) NOT NULL default '0',
  `player` varbinary(255) NOT NULL default '',
  `aid` int(9) unsigned NOT NULL default '0',
  `alliance` varbinary(255) NOT NULL default '',
  `population` smallint(5) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `x_world_speed_travian_hk_090815`
--

CREATE TABLE IF NOT EXISTS `x_world_speed_travian_hk_090815` (
  `id` int(9) unsigned NOT NULL default '0',
  `x` smallint(3) NOT NULL default '0',
  `y` smallint(3) NOT NULL default '0',
  `tid` tinyint(1) unsigned NOT NULL default '0',
  `vid` int(9) unsigned NOT NULL default '0',
  `village` varbinary(255) NOT NULL default '',
  `uid` int(9) NOT NULL default '0',
  `player` varbinary(255) NOT NULL default '',
  `aid` int(9) unsigned NOT NULL default '0',
  `alliance` varbinary(255) NOT NULL default '',
  `population` smallint(5) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `x_world_speed_travian_hk_090816`
--

CREATE TABLE IF NOT EXISTS `x_world_speed_travian_hk_090816` (
  `id` int(9) unsigned NOT NULL default '0',
  `x` smallint(3) NOT NULL default '0',
  `y` smallint(3) NOT NULL default '0',
  `tid` tinyint(1) unsigned NOT NULL default '0',
  `vid` int(9) unsigned NOT NULL default '0',
  `village` varbinary(255) NOT NULL default '',
  `uid` int(9) NOT NULL default '0',
  `player` varbinary(255) NOT NULL default '',
  `aid` int(9) unsigned NOT NULL default '0',
  `alliance` varbinary(255) NOT NULL default '',
  `population` smallint(5) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `x_world_speed_travian_jp_090812`
--

CREATE TABLE IF NOT EXISTS `x_world_speed_travian_jp_090812` (
  `id` int(9) unsigned NOT NULL default '0',
  `x` smallint(3) NOT NULL default '0',
  `y` smallint(3) NOT NULL default '0',
  `tid` tinyint(1) unsigned NOT NULL default '0',
  `vid` int(9) unsigned NOT NULL default '0',
  `village` varbinary(255) NOT NULL default '',
  `uid` int(9) NOT NULL default '0',
  `player` varbinary(255) NOT NULL default '',
  `aid` int(9) unsigned NOT NULL default '0',
  `alliance` varbinary(255) NOT NULL default '',
  `population` smallint(5) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `x_world_speed_travian_jp_090813`
--

CREATE TABLE IF NOT EXISTS `x_world_speed_travian_jp_090813` (
  `id` int(9) unsigned NOT NULL default '0',
  `x` smallint(3) NOT NULL default '0',
  `y` smallint(3) NOT NULL default '0',
  `tid` tinyint(1) unsigned NOT NULL default '0',
  `vid` int(9) unsigned NOT NULL default '0',
  `village` varbinary(255) NOT NULL default '',
  `uid` int(9) NOT NULL default '0',
  `player` varbinary(255) NOT NULL default '',
  `aid` int(9) unsigned NOT NULL default '0',
  `alliance` varbinary(255) NOT NULL default '',
  `population` smallint(5) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `x_world_speed_travian_jp_090814`
--

CREATE TABLE IF NOT EXISTS `x_world_speed_travian_jp_090814` (
  `id` int(9) unsigned NOT NULL default '0',
  `x` smallint(3) NOT NULL default '0',
  `y` smallint(3) NOT NULL default '0',
  `tid` tinyint(1) unsigned NOT NULL default '0',
  `vid` int(9) unsigned NOT NULL default '0',
  `village` varbinary(255) NOT NULL default '',
  `uid` int(9) NOT NULL default '0',
  `player` varbinary(255) NOT NULL default '',
  `aid` int(9) unsigned NOT NULL default '0',
  `alliance` varbinary(255) NOT NULL default '',
  `population` smallint(5) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `x_world_speed_travian_jp_090815`
--

CREATE TABLE IF NOT EXISTS `x_world_speed_travian_jp_090815` (
  `id` int(9) unsigned NOT NULL default '0',
  `x` smallint(3) NOT NULL default '0',
  `y` smallint(3) NOT NULL default '0',
  `tid` tinyint(1) unsigned NOT NULL default '0',
  `vid` int(9) unsigned NOT NULL default '0',
  `village` varbinary(255) NOT NULL default '',
  `uid` int(9) NOT NULL default '0',
  `player` varbinary(255) NOT NULL default '',
  `aid` int(9) unsigned NOT NULL default '0',
  `alliance` varbinary(255) NOT NULL default '',
  `population` smallint(5) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `x_world_speed_travian_jp_090816`
--

CREATE TABLE IF NOT EXISTS `x_world_speed_travian_jp_090816` (
  `id` int(9) unsigned NOT NULL default '0',
  `x` smallint(3) NOT NULL default '0',
  `y` smallint(3) NOT NULL default '0',
  `tid` tinyint(1) unsigned NOT NULL default '0',
  `vid` int(9) unsigned NOT NULL default '0',
  `village` varbinary(255) NOT NULL default '',
  `uid` int(9) NOT NULL default '0',
  `player` varbinary(255) NOT NULL default '',
  `aid` int(9) unsigned NOT NULL default '0',
  `alliance` varbinary(255) NOT NULL default '',
  `population` smallint(5) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `x_world_speed_travian_tw_090812`
--

CREATE TABLE IF NOT EXISTS `x_world_speed_travian_tw_090812` (
  `id` int(9) unsigned NOT NULL default '0',
  `x` smallint(3) NOT NULL default '0',
  `y` smallint(3) NOT NULL default '0',
  `tid` tinyint(1) unsigned NOT NULL default '0',
  `vid` int(9) unsigned NOT NULL default '0',
  `village` varbinary(255) NOT NULL default '',
  `uid` int(9) NOT NULL default '0',
  `player` varbinary(255) NOT NULL default '',
  `aid` int(9) unsigned NOT NULL default '0',
  `alliance` varbinary(255) NOT NULL default '',
  `population` smallint(5) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `x_world_speed_travian_tw_090813`
--

CREATE TABLE IF NOT EXISTS `x_world_speed_travian_tw_090813` (
  `id` int(9) unsigned NOT NULL default '0',
  `x` smallint(3) NOT NULL default '0',
  `y` smallint(3) NOT NULL default '0',
  `tid` tinyint(1) unsigned NOT NULL default '0',
  `vid` int(9) unsigned NOT NULL default '0',
  `village` varbinary(255) NOT NULL default '',
  `uid` int(9) NOT NULL default '0',
  `player` varbinary(255) NOT NULL default '',
  `aid` int(9) unsigned NOT NULL default '0',
  `alliance` varbinary(255) NOT NULL default '',
  `population` smallint(5) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `x_world_speed_travian_tw_090814`
--

CREATE TABLE IF NOT EXISTS `x_world_speed_travian_tw_090814` (
  `id` int(9) unsigned NOT NULL default '0',
  `x` smallint(3) NOT NULL default '0',
  `y` smallint(3) NOT NULL default '0',
  `tid` tinyint(1) unsigned NOT NULL default '0',
  `vid` int(9) unsigned NOT NULL default '0',
  `village` varbinary(255) NOT NULL default '',
  `uid` int(9) NOT NULL default '0',
  `player` varbinary(255) NOT NULL default '',
  `aid` int(9) unsigned NOT NULL default '0',
  `alliance` varbinary(255) NOT NULL default '',
  `population` smallint(5) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `x_world_speed_travian_tw_090815`
--

CREATE TABLE IF NOT EXISTS `x_world_speed_travian_tw_090815` (
  `id` int(9) unsigned NOT NULL default '0',
  `x` smallint(3) NOT NULL default '0',
  `y` smallint(3) NOT NULL default '0',
  `tid` tinyint(1) unsigned NOT NULL default '0',
  `vid` int(9) unsigned NOT NULL default '0',
  `village` varbinary(255) NOT NULL default '',
  `uid` int(9) NOT NULL default '0',
  `player` varbinary(255) NOT NULL default '',
  `aid` int(9) unsigned NOT NULL default '0',
  `alliance` varbinary(255) NOT NULL default '',
  `population` smallint(5) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `x_world_speed_travian_tw_090816`
--

CREATE TABLE IF NOT EXISTS `x_world_speed_travian_tw_090816` (
  `id` int(9) unsigned NOT NULL default '0',
  `x` smallint(3) NOT NULL default '0',
  `y` smallint(3) NOT NULL default '0',
  `tid` tinyint(1) unsigned NOT NULL default '0',
  `vid` int(9) unsigned NOT NULL default '0',
  `village` varbinary(255) NOT NULL default '',
  `uid` int(9) NOT NULL default '0',
  `player` varbinary(255) NOT NULL default '',
  `aid` int(9) unsigned NOT NULL default '0',
  `alliance` varbinary(255) NOT NULL default '',
  `population` smallint(5) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `x_world_speed_travian_us_090812`
--

CREATE TABLE IF NOT EXISTS `x_world_speed_travian_us_090812` (
  `id` int(9) unsigned NOT NULL default '0',
  `x` smallint(3) NOT NULL default '0',
  `y` smallint(3) NOT NULL default '0',
  `tid` tinyint(1) unsigned NOT NULL default '0',
  `vid` int(9) unsigned NOT NULL default '0',
  `village` varbinary(255) NOT NULL default '',
  `uid` int(9) NOT NULL default '0',
  `player` varbinary(255) NOT NULL default '',
  `aid` int(9) unsigned NOT NULL default '0',
  `alliance` varbinary(255) NOT NULL default '',
  `population` smallint(5) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `x_world_speed_travian_us_090813`
--

CREATE TABLE IF NOT EXISTS `x_world_speed_travian_us_090813` (
  `id` int(9) unsigned NOT NULL default '0',
  `x` smallint(3) NOT NULL default '0',
  `y` smallint(3) NOT NULL default '0',
  `tid` tinyint(1) unsigned NOT NULL default '0',
  `vid` int(9) unsigned NOT NULL default '0',
  `village` varbinary(255) NOT NULL default '',
  `uid` int(9) NOT NULL default '0',
  `player` varbinary(255) NOT NULL default '',
  `aid` int(9) unsigned NOT NULL default '0',
  `alliance` varbinary(255) NOT NULL default '',
  `population` smallint(5) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `x_world_speed_travian_us_090814`
--

CREATE TABLE IF NOT EXISTS `x_world_speed_travian_us_090814` (
  `id` int(9) unsigned NOT NULL default '0',
  `x` smallint(3) NOT NULL default '0',
  `y` smallint(3) NOT NULL default '0',
  `tid` tinyint(1) unsigned NOT NULL default '0',
  `vid` int(9) unsigned NOT NULL default '0',
  `village` varbinary(255) NOT NULL default '',
  `uid` int(9) NOT NULL default '0',
  `player` varbinary(255) NOT NULL default '',
  `aid` int(9) unsigned NOT NULL default '0',
  `alliance` varbinary(255) NOT NULL default '',
  `population` smallint(5) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `x_world_speed_travian_us_090815`
--

CREATE TABLE IF NOT EXISTS `x_world_speed_travian_us_090815` (
  `id` int(9) unsigned NOT NULL default '0',
  `x` smallint(3) NOT NULL default '0',
  `y` smallint(3) NOT NULL default '0',
  `tid` tinyint(1) unsigned NOT NULL default '0',
  `vid` int(9) unsigned NOT NULL default '0',
  `village` varbinary(255) NOT NULL default '',
  `uid` int(9) NOT NULL default '0',
  `player` varbinary(255) NOT NULL default '',
  `aid` int(9) unsigned NOT NULL default '0',
  `alliance` varbinary(255) NOT NULL default '',
  `population` smallint(5) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `x_world_speed_travian_us_090816`
--

CREATE TABLE IF NOT EXISTS `x_world_speed_travian_us_090816` (
  `id` int(9) unsigned NOT NULL default '0',
  `x` smallint(3) NOT NULL default '0',
  `y` smallint(3) NOT NULL default '0',
  `tid` tinyint(1) unsigned NOT NULL default '0',
  `vid` int(9) unsigned NOT NULL default '0',
  `village` varbinary(255) NOT NULL default '',
  `uid` int(9) NOT NULL default '0',
  `player` varbinary(255) NOT NULL default '',
  `aid` int(9) unsigned NOT NULL default '0',
  `alliance` varbinary(255) NOT NULL default '',
  `population` smallint(5) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
